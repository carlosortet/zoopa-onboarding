---
name: event-pnl-management
description: Framework completo para gestionar P&L de eventos, incluyendo estructura de presupuestos, targets de margen, control financiero y reconciliacion post-evento. Usar cuando se trabaje con presupuestos de eventos, calculos de margen o analisis financiero de produccion.
---

# Event P&L Management Skill

Framework para la gestion financiera de eventos: presupuestacion, control de margenes, y reconciliacion.

## Estructura de P&L de Evento

```
## P&L TIPO EVENTO

### INGRESOS
├── Fee de produccion/gestion
├── Ingresos por ticketing (si aplica)
├── Aportaciones de sponsors
├── Subsidios/subvenciones (si aplica)
└── Otros ingresos (merchandising, etc.)

### COSTES DIRECTOS
├── Venue (alquiler, servicios)
├── Produccion (escenografia, AV, tech)
├── Catering & F&B
├── Entertainment (talento, artistas)
├── Logistica (transporte, montaje)
├── Staff & personal
├── Marketing & comunicacion
├── Seguros & permisos
└── Contingencia (10-15%)

### MARGEN BRUTO
= Ingresos - Costes Directos

### COSTES INDIRECTOS
├── Overhead empresa (% asignado)
├── Gestion de proyecto
└── Administracion

### MARGEN NETO
= Margen Bruto - Costes Indirectos
```

## Target de Margenes por Tipo de Evento

| Tipo de Evento | Margen Bruto Objetivo | Margen Neto Objetivo |
|----------------|----------------------|---------------------|
| **Corporate (cliente paga todo)** | 25-35% | 15-20% |
| **Brand Activation** | 20-30% | 12-18% |
| **Evento con Ticketing** | 15-25% | 8-15% |
| **Gala/Premiacion** | 20-30% | 12-18% |
| **Festival** | 10-20% | 5-12% |

## Distribucion Tipica de Budget

| Categoria | % Tipico | Notas |
|-----------|----------|-------|
| **Venue** | 25-35% | Alquiler, servicios basicos, exclusividad |
| **Produccion** | 20-30% | Escenografia, AV, tech, iluminacion |
| **Catering** | 15-25% | Comida, bebida, servicio, licencias |
| **Entertainment** | 5-15% | Speakers, artistas, actividades |
| **Marketing** | 5-10% | Invitaciones, promo, materiales, RRPP |
| **Staffing** | 5-10% | Produccion, azafatas, seguridad |
| **Seguros & Permisos** | 2-5% | RC, cancelacion, permisos municipales |
| **Contingencia** | 10-15% | Imprevistos (SIEMPRE incluir) |

## Reglas de Oro para Proteger el Margen

1. **Contingencia sagrada**: Nunca usar para scope creep, solo para imprevistos reales
2. **Tracking semanal**: Actualizar costes reales vs presupuesto
3. **Alertas tempranas**: Si desviacion >5%, comunicar inmediatamente
4. **Cambios de scope**: Siempre con aprobacion escrita y ajuste de presupuesto
5. **Negociacion continua**: Buscar valor en cada proveedor sin sacrificar calidad
6. **Reconciliacion post-evento**: Cierre financiero en maximo 2 semanas

## Template de Budget Control

```markdown
## Control de Budget Semanal

### Resumen
- Presupuesto total: €[X]
- Comprometido a fecha: €[X] ([X]%)
- Gastado real: €[X] ([X]%)
- Contingencia disponible: €[X]

### Por Categoria
| Categoria | Budget | Comprometido | Real | Desviacion |
|-----------|--------|--------------|------|------------|
| Venue | €X | €X | €X | +/-X% |
| Produccion | €X | €X | €X | +/-X% |
| Catering | €X | €X | €X | +/-X% |
| ... | ... | ... | ... | ... |

### Alertas
- [ ] Desviaciones >5%
- [ ] Nuevos compromisos sin aprobar
- [ ] Proveedores pendientes de confirmar

### Acciones Requeridas
1. [Accion 1]
2. [Accion 2]
```

## Cierre Financiero Post-Evento

```markdown
## Reconciliacion Final

### 1. INGRESOS FINALES
| Concepto | Presupuestado | Real | Desviacion |
|----------|---------------|------|------------|
| Fee produccion | €X | €X | +/-X% |
| Ticketing | €X | €X | +/-X% |
| Sponsors | €X | €X | +/-X% |
| **TOTAL INGRESOS** | €X | €X | +/-X% |

### 2. COSTES FINALES
| Categoria | Presupuestado | Real | Desviacion | Notas |
|-----------|---------------|------|------------|-------|
| Venue | €X | €X | +/-X% | |
| Produccion | €X | €X | +/-X% | |
| ... | ... | ... | ... | |
| **TOTAL COSTES** | €X | €X | +/-X% | |

### 3. MARGENES
| Concepto | Objetivo | Real | Status |
|----------|----------|------|--------|
| Margen Bruto | X% | X% | OK/ALERTA |
| Margen Neto | X% | X% | OK/ALERTA |

### 4. ANALISIS DE DESVIACIONES
- Desviacion 1: [Causa] - [Impacto] - [Aprendizaje]
- Desviacion 2: ...

### 5. APRENDIZAJES PARA FUTUROS EVENTOS
- [Aprendizaje 1]
- [Aprendizaje 2]
```

## Formulas Clave

```
Margen Bruto (%) = (Ingresos - Costes Directos) / Ingresos × 100

Margen Neto (%) = (Ingresos - Costes Totales) / Ingresos × 100

Desviacion (%) = (Real - Presupuestado) / Presupuestado × 100

Contingencia Recomendada = Costes Directos × 0.10 a 0.15

Break-even = Costes Fijos / (1 - Costes Variables/Ingresos)
```

## Checklist Pre-Evento Financiero

- [ ] P&L aprobado por cliente
- [ ] Todos los proveedores con contrato firmado
- [ ] Depositos pagados segun calendario
- [ ] Contingencia intacta o desviaciones documentadas
- [ ] Forecast de cierre actualizado
- [ ] Facturacion a cliente programada

## Referencias

- Extraido de: system_prompt_events_production_zoopa
- Relacionado: system_prompt_director_produccion_zoopa
