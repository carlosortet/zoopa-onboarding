---
name: sponsorship-valuation
description: Framework para valoracion de assets de patrocinio, estructuracion de paquetes, pricing basado en valor y negociacion. Usar cuando se necesite crear propuestas de patrocinio, valorar inventario de assets o estructurar deals con sponsors.
---

# Sponsorship Valuation Skill

Framework para valorar, estructurar y vender patrocinios de eventos y contenido.

## Inventario de Assets

### Assets On-Site (Eventos)

| Asset | Descripcion | Valoracion |
|-------|-------------|------------|
| **Naming Rights** | Nombre del evento/area | Premium (€€€€€) |
| **Presenting Sponsor** | "Presentado por [Marca]" | Alta (€€€€) |
| **Main Sponsor** | Logo principal, maxima visibilidad | Alta (€€€) |
| **Official Sponsor** | Categoria exclusiva | Media (€€) |
| **Supporting Sponsor** | Visibilidad basica | Baja (€) |

### Assets de Visibilidad

| Asset | Descripcion | Valoracion |
|-------|-------------|------------|
| **Backdrop principal** | Logo en photocall/escenario | Alta |
| **Branding venue** | Banners, roll-ups, vinilos | Media-Alta |
| **Pantallas LED** | Loops de video/logo | Alta |
| **Materiales impresos** | Programas, invitaciones | Media |
| **Acreditaciones** | Logo en credenciales | Media |
| **Merchandising** | Productos co-branded | Media |

### Assets Experienciales

| Asset | Descripcion | Valoracion |
|-------|-------------|------------|
| **Stand/Activacion** | Espacio propio del sponsor | Alta |
| **Sampling** | Distribucion de producto | Media-Alta |
| **Momento en programa** | Speech, entrega premio | Alta |
| **Hospitality** | Suite VIP, invitaciones | Alta |
| **Meet & Greet** | Acceso a talento/speakers | Alta |
| **Experiencia exclusiva** | Actividad custom | Premium |

### Assets Digitales

| Asset | Descripcion | Valoracion |
|-------|-------------|------------|
| **Presencia web evento** | Logo, landing, links | Media |
| **Email marketing** | Menciones en comunicaciones | Media |
| **Social media** | Posts dedicados, menciones | Media-Alta |
| **Streaming branded** | Logo en retransmision | Alta |
| **Contenido post-evento** | Video highlights branded | Alta |
| **Datos/Leads** | Leads de asistentes | Alta |

## Metodologia de Valoracion

### Principios de Pricing

1. **Valor basado en resultados**, no en costes
2. **Benchmarking** con eventos/proyectos comparables
3. **Escasez y exclusividad** aumentan valor
4. **Customizacion** justifica premium
5. **Historico de renovaciones** valida pricing

### Formulas de Valoracion

```markdown
## VISIBILIDAD ON-SITE
Valor = (Impresiones estimadas) × (CPM referencia) × (Factor calidad)

Ejemplo:
- 5,000 asistentes × 3 horas × 10 impactos/hora = 150,000 impresiones
- CPM referencia sector: €15
- Factor calidad (audiencia premium): 1.5x
- Valor = 150,000 / 1,000 × €15 × 1.5 = €3,375

## DIGITAL
Valor = (Reach) × (CPM plataforma) × (Factor engagement)

## EXPERIENCIAL
Valor = (Participantes) × (Valor contacto cualificado sector)

## DATOS/LEADS
Valor = (Leads estimados) × (Coste por lead sector)
```

### Tabla de Precios de Referencia

| Tipo de Evento | Naming | Main | Official |
|----------------|--------|------|----------|
| **Gala/Premio (500-1000 pax)** | 50-100K€ | 25-50K€ | 10-25K€ |
| **Conferencia (1000-3000 pax)** | 75-150K€ | 40-75K€ | 15-40K€ |
| **Festival (5000+ pax)** | 150-500K€ | 75-150K€ | 30-75K€ |
| **Activacion marca** | N/A | 30-100K€ | 15-30K€ |
| **Serie contenido** | 100-300K€ | 50-100K€ | 20-50K€ |

## Estructura de Propuesta

```markdown
## Propuesta de Patrocinio [Evento/Proyecto]

### 1. OPORTUNIDAD
- Descripcion del evento/proyecto
- Datos clave (fecha, ubicacion, audiencia)
- Por que es relevante para la marca

### 2. AUDIENCIA
- Perfil demografico
- Tamano (asistentes, reach digital)
- Engagement esperado
- Afinidad con la marca

### 3. PAQUETES DE PATROCINIO

#### NAMING PARTNER - [Precio]
- Naming rights completos
- Maxima visibilidad on-site
- Exclusividad de categoria
- Pack digital completo
- Hospitality premium
- Contenido exclusivo

#### MAIN SPONSOR - [Precio]
- Logo principal en materiales
- Stand de activacion
- Momento en programa
- Pack digital
- Hospitality

#### OFFICIAL SPONSOR - [Precio]
- Visibilidad secundaria
- Presencia digital
- Invitaciones VIP
- Menciones en comunicaciones

### 4. VALOR ESTIMADO
- Breakdown de valoracion de assets
- Comparativa con media buying equivalente
- ROI proyectado

### 5. CASOS DE EXITO
- Patrocinadores anteriores
- Resultados conseguidos
- Testimoniales

### 6. PROXIMOS PASOS
- Deadline de decision
- Contacto
- Proceso de cierre
```

## Negociacion

### Gestion de Objeciones

| Objecion | Respuesta |
|----------|-----------|
| "Es muy caro" | Desglosar valor de cada asset, comparar con alternativas |
| "No tenemos presupuesto" | Explorar timing (proximo ano), paquete reducido, canje |
| "Queremos exclusividad total" | Valorar premium, definir alcance de exclusividad |
| "No lo hemos hecho antes" | Casos de exito, reducir riesgo con metricas claras |
| "Competencia lo hace mas barato" | Diferenciar calidad de audiencia, resultados |

### Estructuras de Pago

```markdown
## ESTANDAR
- 50% a la firma
- 50% pre-evento (D-30)

## PARA SPONSORS NUEVOS
- 30% a la firma
- 40% pre-evento (D-30)
- 30% post-evento (D+15)

## ACUERDOS PLURIANUALES
- Descuento 10-15% por compromiso
- Pago escalonado por ano
- Lock-in de precios
```

## Reporting Post-Patrocinio

```markdown
## Informe de Patrocinio [Evento]

### 1. RESUMEN EJECUTIVO
- Highlights del evento
- Performance del patrocinio
- ROI estimado

### 2. DATOS DEL EVENTO
- Asistencia: [X] asistentes
- Perfil: [demografia]
- Engagement: [metricas]

### 3. EXPOSICION DE MARCA

#### On-Site
- Ubicaciones de branding (con fotos)
- Impresiones estimadas
- Tiempo de exposicion

#### Digital
- Menciones en RRSS: [X]
- Reach total: [X]
- Engagement: [X]
- Clicks/traffic: [X]

#### Medios
- Apariciones en prensa
- Earned media value: [€X]

### 4. ACTIVACIONES
- Participantes en activacion: [X]
- Sampling/demos: [X]
- Leads capturados: [X]

### 5. VALORACION FINAL
- Valor contratado: [€X]
- Valor entregado estimado: [€X]
- ROI: [X]x

### 6. PROXIMOS PASOS
- Propuesta de renovacion
- Mejoras sugeridas
```

## Pipeline de Patrocinios

| Fase | Descripcion | Probabilidad |
|------|-------------|--------------|
| **Prospecto** | Marca identificada, sin contacto | 5% |
| **Contactado** | Primera reunion realizada | 15% |
| **Propuesta enviada** | Dossier presentado | 30% |
| **Negociacion** | Discutiendo terminos | 50% |
| **Verbal OK** | Acuerdo verbal | 75% |
| **Firmado** | Contrato firmado | 100% |

## Referencias

- Extraido de: system_prompt_sponsorships_specialist_zoopa
- Relacionado: system_prompt_events_production_zoopa
