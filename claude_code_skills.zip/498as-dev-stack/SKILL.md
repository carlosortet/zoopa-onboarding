---
name: 498as-dev-stack
description: Stack tecnologico completo de 498AS incluyendo Bun, Hono, React, TanStack, Drizzle, PostgreSQL, Vercel AI SDK y arquitectura de cinco planos. Usar cuando se desarrolle software para 498AS o se necesite referencia del stack tecnologico.
---

# 498AS Development Stack Skill

Stack tecnologico y patrones de desarrollo para proyectos 498AS.

## Arquitectura de Cinco Planos

```mermaid
graph TD
    A[Plano Edge - Cloudflare] --> B[Plano de Control - Coolify]
    B --> C[Plano de Aplicacion - Apps/APIs]
    C --> D[Plano de Datos - PostgreSQL/Redis/Convex]
    C --> E[Plano de Ejecucion - Daytona Sandboxes]
```

| Plano | Tecnologias | Proposito |
|-------|-------------|-----------|
| **Edge** | Cloudflare (DNS, WAF, CDN) | Seguridad, cache, routing |
| **Control** | Coolify, GitHub | Despliegue, CI/CD |
| **Aplicacion** | Bun, Hono, React | Apps y APIs |
| **Datos** | PostgreSQL, Redis, Convex | Persistencia, colas, vectores |
| **Ejecucion** | Daytona | Sandboxes aislados para IA |

## Stack Tecnologico

### Runtime y Build

| Herramienta | Proposito |
|-------------|-----------|
| **Bun** | Runtime JS/TS principal |
| **Vite** | Build tool y dev server |
| **Turborepo** | Monorepos |
| **OrbStack** | Docker local (macOS) |

### Frontend

| Herramienta | Proposito |
|-------------|-----------|
| **React 18/19** | UI framework |
| **TanStack Router** | Routing type-safe |
| **TanStack Query** | Server state y data fetching |
| **TanStack Form** | Gestion de formularios |
| **TanStack Table** | Tablas de datos |
| **Zustand** | Client state management |
| **Tailwind CSS v4** | Utility-first CSS |
| **Radix UI** | Primitivos accesibles |
| **shadcn/ui** | Componentes pre-construidos |
| **Framer Motion** | Animaciones |
| **Lucide React** | Iconos |
| **Recharts** | Graficos |
| **React Flow** | Diagramas de nodos |

### Backend

| Herramienta | Proposito |
|-------------|-----------|
| **Hono** | Framework web ligero |
| **tRPC** | APIs type-safe end-to-end |
| **Drizzle ORM** | Acceso a BD type-safe |
| **BullMQ** | Colas de trabajos |
| **Bull Board** | UI de monitoreo de colas |
| **Pino** | Logging estructurado |
| **better-auth** | Autenticacion |

### Datos

| Tecnologia | Uso |
|------------|-----|
| **PostgreSQL** | Base de datos principal |
| **Redis** | Cache, sesiones, colas |
| **Convex** | Vectores, tiempo real |

### AI/LLM

| Herramienta | Proposito |
|-------------|-----------|
| **Vercel AI SDK** | Interfaz unificada para LLMs |
| **@ai-sdk/anthropic** | Integracion con Claude |
| **@ai-sdk/openai** | Integracion con OpenAI |
| **@ai-sdk/google** | Integracion con Google AI |

## Estructura de Proyecto

```
proyecto/
├── src/
│   ├── app/                 # Routes (TanStack Router)
│   ├── components/          # Componentes React
│   │   ├── ui/              # shadcn/ui components
│   │   └── features/        # Feature-specific
│   ├── lib/                 # Utilidades
│   ├── hooks/               # Custom hooks
│   ├── server/              # Backend (Hono/tRPC)
│   │   ├── routes/          # API routes
│   │   ├── db/              # Drizzle schema y queries
│   │   └── services/        # Business logic
│   ├── types/               # TypeScript types
│   └── styles/              # Tailwind y estilos
├── public/                  # Assets estaticos
├── tests/                   # Playwright tests
├── drizzle/                 # Migrations
├── CLAUDE.md                # Contexto para IA
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── vite.config.ts
```

## Patrones de Codigo

### API con Hono + tRPC

```typescript
// server/trpc/router.ts
import { router, publicProcedure, protectedProcedure } from './trpc';
import { z } from 'zod';

export const appRouter = router({
  getItems: publicProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(async ({ input, ctx }) => {
      return ctx.db.query.items.findMany({
        limit: input.limit ?? 10,
      });
    }),
  
  createItem: protectedProcedure
    .input(z.object({ name: z.string(), data: z.any() }))
    .mutation(async ({ input, ctx }) => {
      return ctx.db.insert(items).values({
        name: input.name,
        data: input.data,
        userId: ctx.user.id,
      });
    }),
});
```

### Data Fetching con TanStack Query

```typescript
// hooks/useItems.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { trpc } from '@/lib/trpc';

export function useItems(limit?: number) {
  return useQuery({
    queryKey: ['items', limit],
    queryFn: () => trpc.getItems.query({ limit }),
  });
}

export function useCreateItem() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: trpc.createItem.mutate,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['items'] });
    },
  });
}
```

### Integracion con LLMs

```typescript
// server/services/ai.ts
import { generateText, streamText } from 'ai';
import { anthropic } from '@ai-sdk/anthropic';

export async function generateAnalysis(data: string) {
  const result = await generateText({
    model: anthropic('claude-3-5-sonnet-20241022'),
    system: 'Eres un analista de datos experto...',
    prompt: `Analiza los siguientes datos: ${data}`,
  });
  
  return result.text;
}
```

### Drizzle ORM

```typescript
// server/db/schema.ts
import { pgTable, text, timestamp, jsonb } from 'drizzle-orm/pg-core';
import { nanoid } from 'nanoid';

export const projects = pgTable('projects', {
  id: text('id').primaryKey().$defaultFn(() => nanoid()),
  name: text('name').notNull(),
  data: jsonb('data'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});
```

## Ejecucion con Daytona

> **REGLA CRITICA**: Todo codigo generado por IA o archivos de usuarios DEBE ejecutarse en Daytona, NUNCA en el servidor de produccion.

| Escenario | Daytona? | Razon |
|-----------|----------|-------|
| Parsear Excel del usuario | Si | Input no confiable |
| Ejecutar codigo generado por LLM | Si | Codigo impredecible |
| Query a la base de datos | No | Operacion controlada |
| Renderizar React | No | Codigo confiable |

## Comandos de Desarrollo

```bash
# Setup
git clone git@github.com:498AS/[proyecto].git
cd [proyecto]
bun install
cp .env.example .env.local

# Desarrollo
bun dev          # Dev server
bun check-types  # Verificar tipos
bun lint         # Linting
bun build        # Build produccion

# Base de datos
bun db:push      # Aplicar schema
bun db:studio    # Drizzle Studio
```

## Naming Conventions

```typescript
// Componentes: PascalCase
export function UserProfile() {}

// Hooks: camelCase con use prefix
export function useUserData() {}

// Funciones: camelCase
export function calculateTotal() {}

// Constantes: SCREAMING_SNAKE_CASE
export const MAX_ITEMS = 100;

// Types/Interfaces: PascalCase
interface UserData {}
type ProjectStatus = 'active' | 'archived';

// Archivos: kebab-case
// user-profile.tsx
// use-user-data.ts
```

## Checklist Pre-Deploy

- [ ] Tests pasan localmente
- [ ] Types check: `bun check-types`
- [ ] Lint limpio: `bun lint`
- [ ] Build exitoso: `bun build`
- [ ] Variables de entorno en Coolify
- [ ] Migrations de BD aplicadas
- [ ] Feature flag si es feature grande

## Referencias

- Extraido de: system_prompt_developer_498as
- Relacionado: 498AS_Guia_Arquitectura_Sistemas_v2
