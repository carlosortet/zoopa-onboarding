---
name: file-naming-system
description: Sistema de nomenclatura de archivos ZOOPA/498AS con formato estandarizado para todos los documentos. Usar cuando se creen documentos, informes, propuestas o cualquier entregable que requiera nombrado consistente.
---

# File Naming System Skill

Sistema estandarizado de nomenclatura de archivos para ZOOPA y 498AS.

## Formato General

```
[TIPO_DOC]_[PROYECTO]_[CLIENTE]_[IDIOMA]_[VERSION]_[EMPRESA]_[AUTOR]_[FECHA].ext
```

## Elementos del Nombre

| Elemento | Formato | Descripcion | Ejemplo |
|----------|---------|-------------|---------|
| **TIPO_DOC** | MAYUSCULAS | Tipo de documento | `BRIEF`, `PROPUESTA`, `INFORME` |
| **PROYECTO** | Dos_Palabras | Nombre del proyecto | `Content_Anual`, `SEO_Tecnico` |
| **CLIENTE** | SinEspacios | Nombre del cliente | `ClienteXYZ`, `MarcaABC` |
| **IDIOMA** | 3 letras (opcional) | Idioma del documento | `CAT`, `CAST`, `ENG` |
| **VERSION** | vXX | Numero de version | `v01`, `v02`, `v10` |
| **EMPRESA** | ZOOPA/498AS | Empresa que produce | `ZOOPA`, `498AS` |
| **AUTOR** | 3 letras | Iniciales del autor | `JGA`, `COP`, `MRA` |
| **FECHA** | YYYYMMDD | Fecha de creacion | `20240302`, `20250106` |

## Tipos de Documento por Area

### Estrategia y Marketing

| Tipo | Uso |
|------|-----|
| `ESTRATEGIA` | Documentos estrategicos |
| `BRIEF` | Briefs de proyecto |
| `PROPUESTA` | Propuestas comerciales |
| `BENCHMARK` | Analisis de competencia |
| `AUDIT` | Auditorias |
| `CALENDARIO` | Calendarios editoriales |

### Eventos y Produccion

| Tipo | Uso |
|------|-----|
| `PRODUCCION` | Production books |
| `RUNSHOW` | Run of show |
| `PLANO` | Floor plans |
| `RIESGOS` | Matrices de riesgos |
| `PERMISOS` | Checklists de permisos |
| `VENDOR` | Matrices de proveedores |
| `PL` | P&L de eventos |
| `BUDGET` | Presupuestos |

### SEO y Digital

| Tipo | Uso |
|------|-----|
| `AUDIT` | Auditorias SEO/GEO |
| `RESEARCH` | Investigacion de keywords |
| `DASHBOARD` | Dashboards de KPIs |
| `ROADMAP` | Roadmaps de optimizacion |
| `LLMSTXT` | Configuraciones llms.txt |

### Patrocinios y Comercial

| Tipo | Uso |
|------|-----|
| `DOSSIER` | Dossiers de patrocinio |
| `CONTRATO` | Contratos |
| `INVENTARIO` | Inventarios de assets |

### Informes y Reportes

| Tipo | Uso |
|------|-----|
| `INFORME` | Informes generales |
| `REPORT` | Reports en ingles |
| `ANALISIS` | Analisis especificos |

### Desarrollo y Tecnico

| Tipo | Uso |
|------|-----|
| `SPEC` | Especificaciones tecnicas |
| `DOC` | Documentacion |
| `README` | Archivos readme |
| `ARCH` | Arquitectura |

## Ejemplos por Departamento

### Content Strategy
```
ESTRATEGIA_Content_Anual_ClienteXYZ_v01_ZOOPA_JGA_20240302.pdf
CALENDARIO_Editorial_Q1_ClienteABC_v02_ZOOPA_MRA_20240315.xlsx
AUDIT_Content_Performance_Cliente123_v01_ZOOPA_COP_20240401.pdf
BRIEF_Campana_Navidad_ClienteXYZ_v01_ZOOPA_AML_20241015.docx
```

### Eventos
```
BRIEF_Evento_Lanzamiento_ClienteXYZ_v01_ZOOPA_JGA_20240302.pdf
PROPUESTA_Evento_Anual_ClienteABC_v02_ZOOPA_MRA_20240315.pdf
BUDGET_Convencion_2024_Cliente123_v03_ZOOPA_COP_20240401.xlsx
PL_Evento_Gala_MarcaABC_v01_ZOOPA_EBO_20241015.xlsx
PRODUCCION_Book_EventoXYZ_v01_ZOOPA_AML_20241015.pdf
RUNSHOW_Gala_Premios_MarcaABC_v02_ZOOPA_EBO_20241020.xlsx
RIESGOS_Matriz_EventoXYZ_v01_ZOOPA_COP_20241020.xlsx
INFORME_PostEvento_Lanzamiento_ClienteXYZ_v01_ZOOPA_LCA_20241101.pdf
```

### SEO & GEO
```
AUDIT_SEO_Tecnico_ClienteXYZ_v01_498AS_COP_20240302.pdf
INFORME_Ranking_Mensual_ClienteABC_v02_498AS_TAW_20240315.pdf
ESTRATEGIA_SEO_Anual_Cliente123_v01_498AS_JGA_20240401.docx
DASHBOARD_KPIs_SEO_MarcaNueva_v01_498AS_MRA_20240501.xlsx
AUDIT_GEO_Visibilidad_ClienteXYZ_v01_498AS_COP_20240302.pdf
LLMSTXT_Configuracion_Web_ClienteXYZ_v01_498AS_COP_20240601.txt
```

### Patrocinios
```
DOSSIER_Patrocinio_EventoXYZ_v01_ZOOPA_JGA_20240302.pdf
PROPUESTA_Sponsor_MarcaABC_v02_ZOOPA_MRA_20240315.pdf
CONTRATO_Patrocinio_MarcaXYZ_v01_ZOOPA_COP_20240401.pdf
INVENTARIO_Assets_Evento2024_v01_ZOOPA_AML_20240501.xlsx
INFORME_PostPatrocinio_MarcaABC_v01_ZOOPA_EBO_20240601.pdf
```

### Desarrollo
```
SPEC_API_Dashboard_ClienteXYZ_v01_498AS_JGA_20240302.md
DOC_Arquitectura_Sistema_v02_498AS_MRA_20240315.md
README_Proyecto_ClienteABC_v01_498AS_COP_20240401.md
```

## Reglas Adicionales

### Idiomas
- `CAST` - Castellano
- `CAT` - Catalan
- `ENG` - Ingles
- Omitir si el idioma es obvio por el contexto

### Versiones
- Empezar siempre en `v01`
- Incrementar para cambios significativos
- Usar `v01_draft` para borradores si es necesario

### Fechas
- Siempre formato `YYYYMMDD`
- Fecha de creacion, no de modificacion
- Para versiones, mantener fecha de version original

### Extensiones Comunes
| Extension | Uso |
|-----------|-----|
| `.pdf` | Documentos finales, propuestas |
| `.docx` | Documentos editables |
| `.xlsx` | Hojas de calculo, budgets |
| `.pptx` | Presentaciones |
| `.md` | Documentacion tecnica |
| `.txt` | Configuraciones (llms.txt) |

## Validacion de Nombre

Un nombre valido debe:
- [ ] Tener todos los elementos requeridos
- [ ] Usar MAYUSCULAS para TIPO_DOC
- [ ] Usar guiones bajos (_) como separadores
- [ ] No tener espacios
- [ ] Tener fecha en formato YYYYMMDD
- [ ] Tener version en formato vXX
- [ ] Tener extension apropiada

## Referencias

- Extraido de: Todos los system prompts ZOOPA/498AS
- Documento central: zoopa_498AS_file_naming_system
