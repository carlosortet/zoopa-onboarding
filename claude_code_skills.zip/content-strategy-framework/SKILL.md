---
name: content-strategy-framework
description: Framework completo de estrategia de contenidos incluyendo Content Pillars (Hero/Hub/Hygiene), calendario editorial, content audit, KPIs por objetivo y workflow de produccion. Usar cuando se necesite planificar estrategia de contenidos, crear calendarios editoriales o auditar contenido existente.
---

# Content Strategy Framework Skill

Framework estructurado para disenar, planificar y ejecutar estrategias de contenido.

## Proceso de Estrategia de Contenidos

```mermaid
graph LR
    A[1. Discovery] --> B[2. Auditoria]
    B --> C[3. Estrategia]
    C --> D[4. Calendario]
    D --> E[5. Ejecucion]
    E --> F[6. Medicion]
    F --> G[7. Optimizacion]
    G --> D
```

## Framework de Content Pillars

### Modelo Hero-Hub-Hygiene-Help

| Pilar | Descripcion | Objetivo | % del Mix | Formatos |
|-------|-------------|----------|-----------|----------|
| **Hero** | Grandes campanas, momentos clave | Awareness masivo | 10% | Video campana, eventos, stunts |
| **Hub** | Contenido regular de valor | Engagement, loyalty | 30% | Blog, podcast, newsletter, series |
| **Hygiene** | Contenido evergreen, respuestas | SEO, conversion | 50% | FAQs, guias, tutoriales, how-to |
| **Help** | Atencion y soporte | Retencion, NPS | 10% | Social responses, chatbot, FAQ |

### Definicion de Territorios (3-5 por marca)

```markdown
## Template: Content Pillars

### PILAR 1: [Nombre del Territorio]
- **Descripcion**: [De que trata este territorio]
- **Por que es relevante**: [Conexion con marca y audiencia]
- **Keywords principales**: [5-10 keywords]
- **Formatos prioritarios**: [Blog, video, social, etc.]
- **Frecuencia**: [X piezas/mes]
- **Ejemplo de contenido**: [Titulo de ejemplo]

### PILAR 2: [Nombre]
...
```

## Content Audit Framework

### Fase 1: Inventario

| Campo | Descripcion |
|-------|-------------|
| URL | Direccion de la pieza |
| Titulo | Titulo del contenido |
| Formato | Blog, video, infografia, etc. |
| Pilar | Hero/Hub/Hygiene/Help |
| Fecha publicacion | Cuando se publico |
| Fecha actualizacion | Ultima actualizacion |
| Autor | Quien lo creo |

### Fase 2: Analisis de Performance

| Metrica | Fuente | Benchmark |
|---------|--------|-----------|
| Pageviews | GA4 | vs promedio |
| Time on page | GA4 | > 2 min |
| Bounce rate | GA4 | < 60% |
| Organic traffic | GSC | Tendencia |
| Backlinks | Ahrefs | > 0 |
| Social shares | Sprout | > promedio |
| Conversiones | GA4 | > 0 |

### Fase 3: Categorizacion

```markdown
## Resultado del Audit

### KEEP (Alto rendimiento)
- [URL 1] - [Razon]
- [URL 2] - [Razon]

### UPDATE (Potencial, necesita refresh)
- [URL 1] - [Que actualizar]
- [URL 2] - [Que actualizar]

### MERGE (Contenido similar, consolidar)
- [URL 1 + URL 2] -> [Nueva URL]

### DELETE (Sin valor, thin content)
- [URL 1] - [Razon]

### CREATE (Gaps identificados)
- [Tema 1] - [Keyword target]
- [Tema 2] - [Keyword target]
```

## Calendario Editorial

### Estructura del Calendario

| Campo | Descripcion |
|-------|-------------|
| **Fecha** | Dia de publicacion |
| **Canal** | Instagram, Blog, LinkedIn, etc. |
| **Formato** | Video, post, articulo, story |
| **Pilar** | Hero/Hub/Hygiene/Help |
| **Titulo/Concepto** | Idea principal |
| **CTA** | Call to action |
| **Responsable** | Quien produce |
| **Status** | Idea/Borrador/Revision/Aprobado/Publicado |
| **KPI** | Metrica principal |

### Frecuencia Recomendada por Canal

| Canal | Frecuencia Minima | Frecuencia Optima |
|-------|-------------------|-------------------|
| Instagram Feed | 3x semana | 5-7x semana |
| Instagram Stories | 1x dia | 3-5x dia |
| TikTok | 3x semana | 1x dia |
| LinkedIn | 2x semana | 4-5x semana |
| Blog | 2x mes | 1x semana |
| Newsletter | 1x mes | 1x semana |
| YouTube | 2x mes | 1x semana |

## KPIs por Objetivo

| Objetivo | KPIs Principales |
|----------|------------------|
| **Awareness** | Reach, Impressions, Share of Voice |
| **Engagement** | Likes, Comments, Shares, Time on Page |
| **Traffic** | Sessions, Users, Page Views |
| **Leads** | Form Submissions, Downloads, Signups |
| **Conversion** | Sales, Revenue, ROAS |
| **Loyalty** | Return Visitors, Newsletter Opens, NPS |

### Dashboard Template

```markdown
## Content Performance Dashboard

### METRICAS SEMANALES
- Contenidos publicados vs planificados: [X/X]
- Engagement rate promedio: [X]%
- Top 3 contenidos:
  1. [Titulo] - [Metrica]
  2. [Titulo] - [Metrica]
  3. [Titulo] - [Metrica]
- Reach total: [X]

### METRICAS MENSUALES
- Crecimiento de audiencia: +[X]%
- Traffic from content: [X] sessions
- Leads generados: [X]
- Content performance by pillar:
  - Hero: [X] reach, [X]% engagement
  - Hub: [X] reach, [X]% engagement
  - Hygiene: [X] organic sessions
- ROI de contenido: [X]x

### METRICAS TRIMESTRALES
- Share of Voice vs competencia: [X]%
- Brand sentiment: [Positivo/Neutral/Negativo]
- Customer journey attribution: [X]% contenido
- Content audit update: [fecha]
```

## Workflow de Produccion

```mermaid
graph TD
    A[Content Strategist: Brief] --> B[Copywriter: Draft]
    B --> C[Content Strategist: Review]
    C --> D[Creativo: Diseno]
    D --> E[Content Strategist: QA]
    E --> F[Account: Aprobacion Cliente]
    F --> G[Social/Paid: Publicacion]
    G --> H[Content Strategist: Analisis]
```

### Template de Content Brief

```markdown
## Content Brief

### INFORMACION BASICA
- **Titulo provisional**: 
- **Pilar**: Hero / Hub / Hygiene / Help
- **Formato**: 
- **Canal(es)**: 
- **Fecha publicacion**: 
- **Responsable**: 

### OBJETIVO
- **Objetivo del contenido**: 
- **KPI principal**: 
- **CTA**: 

### AUDIENCIA
- **Buyer persona**: 
- **Etapa del funnel**: Awareness / Consideration / Decision
- **Pain point que resuelve**: 

### CONTENIDO
- **Keyword principal**: 
- **Keywords secundarias**: 
- **Angulo/enfoque**: 
- **Puntos clave a cubrir**:
  1. 
  2. 
  3. 
- **Referencias/fuentes**: 

### ESPECIFICACIONES
- **Longitud**: [X palabras / X minutos]
- **Tono**: 
- **Elementos visuales necesarios**: 
- **Links internos sugeridos**: 

### COMPETENCIA
- **Contenido similar de competencia**: [URLs]
- **Diferenciacion**: 
```

## Discovery Questions

```markdown
## Preguntas de Discovery para Estrategia de Contenidos

### Sobre el Negocio
1. "Cual es el principal problema de negocio que el contenido debe resolver?"
2. "Como genera ingresos tu empresa? Cual es el customer lifetime value?"
3. "Que hace tu competencia en contenidos que te preocupa o admiras?"

### Sobre la Audiencia
4. "Describeme a tu cliente ideal en 3 frases"
5. "Que preguntas te hacen tus clientes antes de comprar?"
6. "Donde buscan informacion tus clientes potenciales?"

### Sobre el Contenido
7. "Que contenido habeis creado que haya funcionado muy bien?"
8. "Hay temas o formatos que no debamos tocar?"
9. "Quien puede aportar expertise interno para el contenido?"

### Sobre Objetivos
10. "Como mediremos el exito de la estrategia de contenidos?"
```

## Entregables de Content Strategy

- [ ] **Content Strategy Document**: Estrategia completa con pillars, mix, KPIs
- [ ] **Editorial Calendar**: Calendario trimestral detallado
- [ ] **Content Audit Report**: Analisis del contenido existente
- [ ] **Content Brief Template**: Plantilla para briefs
- [ ] **Monthly Performance Report**: Informe mensual
- [ ] **Competitor Content Analysis**: Benchmark de competencia

## Referencias

- Extraido de: system_prompt_content_strategist_zoopa
- Relacionado: system_prompt_copywriter_zoopa, system_prompt_social_media_mngr_zoopa
