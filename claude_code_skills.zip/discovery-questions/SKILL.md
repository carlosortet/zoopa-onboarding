---
name: discovery-questions
description: Banco de preguntas de discovery por tipo de proyecto (contenido, eventos, SEO, desarrollo, patrocinios). Usar al inicio de cualquier proyecto para recopilar informacion critica del cliente antes de comenzar el trabajo.
---

# Discovery Questions Skill

Banco estructurado de preguntas de discovery para diferentes tipos de proyectos.

## Por que Discovery

> **Regla de oro**: Si falta informacion critica, SOLICITARLA antes de avanzar.

El discovery correcto:
- Evita retrabajo y cambios de scope
- Alinea expectativas desde el inicio
- Identifica restricciones temprano
- Establece criterios de exito claros

## Discovery General (Todo Proyecto)

```markdown
## Contexto del Cliente

### Sobre la Empresa
1. "Describeme tu empresa en 2-3 frases"
2. "Cual es vuestro modelo de negocio?"
3. "Quienes son vuestros competidores principales?"
4. "Cual es vuestro diferenciador clave?"

### Sobre el Proyecto
5. "Cual es el problema que quereis resolver?"
6. "Por que es importante resolverlo ahora?"
7. "Que habeis intentado antes? Que funciono/no funciono?"
8. "Cual seria el resultado ideal?"

### Restricciones
9. "Cual es el presupuesto disponible?"
10. "Cual es el timeline?"
11. "Quien toma las decisiones finales?"
12. "Hay restricciones legales, de marca o compliance?"

### Exito
13. "Como mediremos el exito del proyecto?"
14. "Que KPIs son los mas importantes?"
15. "Que pasaria si no hacemos nada?"
```

## Discovery: Estrategia de Contenidos

```markdown
## Preguntas Content Strategy

### Sobre el Negocio
1. "Cual es el principal problema de negocio que el contenido debe resolver?"
2. "Como genera ingresos tu empresa? Cual es el customer lifetime value?"
3. "Que hace tu competencia en contenidos que te preocupa o admiras?"

### Sobre la Audiencia
4. "Describeme a tu cliente ideal en 3 frases"
5. "Que preguntas te hacen tus clientes antes de comprar?"
6. "Donde buscan informacion tus clientes potenciales?"
7. "Que les frustra de las soluciones actuales?"

### Sobre el Contenido
8. "Que contenido habeis creado que haya funcionado muy bien?"
9. "Hay temas o formatos que no debamos tocar?"
10. "Quien puede aportar expertise interno para el contenido?"
11. "Teneis brand guidelines o tono de voz definido?"

### Sobre Objetivos
12. "Como mediremos el exito de la estrategia de contenidos?"
13. "Cual es el objetivo principal: awareness, leads, ventas, otro?"
14. "Que recursos internos hay para crear/revisar contenido?"
```

## Discovery: Eventos

```markdown
## Preguntas Event Production

### Sobre el Evento
1. "Cual es el unico mensaje que quieres que los asistentes recuerden?"
2. "Que emocion quieres que sientan durante y despues del evento?"
3. "Hay elementos no negociables (speakers, actividades, etc.)?"
4. "Es primera edicion o tiene historico?"

### Sobre la Audiencia
5. "Quienes son los asistentes? Que les motiva?"
6. "Han asistido a eventos similares? Que esperan?"
7. "Hay VIPs o stakeholders que requieren atencion especial?"
8. "Cuantos asistentes esperais?"

### Sobre Logistica
9. "Hay fecha y ubicacion fijas o flexibles?"
10. "Cual es el presupuesto total? Como esta distribuido?"
11. "Necesitais cobertura de contenido (foto, video, streaming)?"
12. "El evento es presencial, virtual o hibrido?"

### Sobre Exito y Negocio
13. "Como mediremos el exito del evento?"
14. "Hay objetivos de negocio detras (leads, ventas, PR)?"
15. "Cual es el margen objetivo del proyecto?"
16. "Que pasaria si el evento no se hace? Que se pierde?"
```

## Discovery: SEO/GEO

```markdown
## Preguntas SEO & GEO Audit

### Situacion Actual
1. "Teneis acceso a Google Analytics y Search Console?"
2. "Habeis hecho auditorias SEO anteriores? Resultados?"
3. "Cual es vuestro trafico organico actual?"
4. "Teneis contenido que ya rankea bien?"

### Objetivos
5. "Que keywords son prioritarias para el negocio?"
6. "Quereis mas trafico, mas leads, o mas ventas?"
7. "Hay mercados geograficos prioritarios?"
8. "Visibilidad en LLMs (ChatGPT, etc.) es importante?"

### Competencia
9. "Quienes son vuestros competidores en busqueda?"
10. "Hay competidores que rankean mejor que vosotros?"
11. "Que hacen ellos que os gustaria replicar?"

### Recursos
12. "Teneis equipo de desarrollo para cambios tecnicos?"
13. "Teneis capacidad de crear contenido nuevo?"
14. "Cual es el presupuesto mensual para SEO?"

### Tecnico
15. "El sitio es WordPress, custom, otro CMS?"
16. "Habeis tenido migraciones recientes?"
17. "Hay problemas tecnicos conocidos?"
```

## Discovery: Desarrollo Software

```markdown
## Preguntas Development

### Problema
1. "Que problema resuelve esta aplicacion/feature?"
2. "Quien la va a usar? Con que frecuencia?"
3. "Que alternativas usan actualmente?"

### Requisitos
4. "Cuales son las funcionalidades imprescindibles?"
5. "Cuales son nice-to-have para futuro?"
6. "Hay integraciones necesarias con otros sistemas?"
7. "Cual es el volumen esperado (usuarios, datos)?"

### Tecnico
8. "Hay stack tecnologico obligatorio?"
9. "Donde se va a desplegar (cloud, on-premise)?"
10. "Hay requisitos de seguridad especiales?"
11. "Necesita funcionar offline?"

### Timeline
12. "Cual es la fecha de lanzamiento?"
13. "Hay hitos intermedios obligatorios?"
14. "Es mejor lanzar rapido o lanzar completo?"

### Mantenimiento
15. "Quien mantendra el codigo despues?"
16. "Hay equipo interno de desarrollo?"
17. "Que nivel de documentacion necesitais?"
```

## Discovery: Patrocinios

```markdown
## Preguntas Sponsorships

### Sobre el Evento/Proyecto
1. "Describeme el evento/proyecto en 2-3 frases"
2. "Cual es la audiencia (tamano, perfil, engagement)?"
3. "Que marcas han patrocinado antes? Con que resultados?"
4. "Que hace este evento diferente de otros similares?"

### Inventario
5. "Que assets de visibilidad teneis disponibles?"
6. "Que experiencias/activaciones son posibles?"
7. "Que contenido digital podeis ofrecer?"
8. "Hay datos/leads que podais compartir con sponsors?"

### Objetivos
9. "Cual es el target de ingresos por patrocinio?"
10. "Hay categorias de sponsor prioritarias?"
11. "Necesitais sponsors de prestigio o volumen de ingresos?"

### Restricciones
12. "Hay categorias excluidas (competidores, sectores)?"
13. "Hay exclusividades ya comprometidas?"
14. "Cual es el deadline para cerrar sponsors?"
```

## Formato de Documentacion

```markdown
## Discovery Brief - [Proyecto]

### Informacion del Cliente
- **Cliente**: [Nombre]
- **Sector**: [Sector]
- **Contacto principal**: [Nombre] - [Email] - [Telefono]
- **Fecha discovery**: [DD/MM/YYYY]

### Contexto
[Resumen de la situacion actual y necesidad]

### Objetivos
1. [Objetivo 1]
2. [Objetivo 2]
3. [Objetivo 3]

### Restricciones
- **Budget**: [X]
- **Timeline**: [Fecha]
- **Otras**: [Lista]

### KPIs de Exito
| KPI | Target | Actual |
|-----|--------|--------|
| [KPI 1] | [Target] | [Baseline] |
| [KPI 2] | [Target] | [Baseline] |

### Stakeholders
| Nombre | Rol | Poder de Decision |
|--------|-----|-------------------|
| [Nombre] | [Rol] | Alto/Medio/Bajo |

### Informacion Pendiente
- [ ] [Dato que falta]
- [ ] [Dato que falta]

### Proximos Pasos
1. [Accion 1] - [Responsable] - [Fecha]
2. [Accion 2] - [Responsable] - [Fecha]
```

## Tips de Discovery

1. **Escucha mas de lo que hablas** - El cliente tiene el contexto
2. **Pregunta "por que" 3 veces** - Llega a la raiz del problema
3. **Documenta en tiempo real** - No confies en la memoria
4. **Confirma entendimiento** - Repite lo que has entendido
5. **Identifica decision-makers** - Saber quien aprueba
6. **No prometas en discovery** - Solo recopila informacion

## Referencias

- Extraido de: Todos los system prompts ZOOPA/498AS
- Aplicable a: Cualquier proyecto con cliente
