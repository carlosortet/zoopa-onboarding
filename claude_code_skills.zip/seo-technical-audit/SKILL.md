---
name: seo-technical-audit
description: Framework completo para auditorias SEO tecnicas, incluyendo checklist de crawling, indexacion, Core Web Vitals, schema markup y priorizacion de tareas por ROI. Usar cuando se necesite auditar un sitio web, identificar problemas tecnicos SEO o crear roadmaps de optimizacion.
---

# SEO Technical Audit Skill

Framework estructurado para realizar auditorias SEO tecnicas completas y priorizadas.

## Workflow de Auditoria

```mermaid
graph LR
    A[1. Data Discovery] --> B[2. Technical Audit]
    B --> C[3. Content Audit]
    C --> D[4. Prioritization]
    D --> E[5. Roadmap]
```

## Fase 1: Data Discovery

### Fuentes de Datos a Recopilar

| Fuente | Datos | Herramienta |
|--------|-------|-------------|
| **Search Console** | Clicks, impressions, CTR, posicion media | GSC |
| **Analytics** | Traffic organico, bounce, conversiones | GA4 |
| **Crawl Data** | URLs, status codes, canonicals | Screaming Frog/Sitebulb |
| **Backlinks** | DR, referring domains, toxicity | Ahrefs/Semrush |
| **Keywords** | Rankings, visibility, gaps | Semrush/DataForSEO |
| **Core Web Vitals** | LCP, FID, CLS | PageSpeed Insights |

## Fase 2: Technical SEO Checklist

### Crawling & Indexacion

```markdown
## Checklist Crawling

### Robots.txt
- [ ] Archivo accesible en /robots.txt
- [ ] No bloquea recursos criticos (CSS, JS)
- [ ] Sitemap referenciado
- [ ] User-agents correctos

### Sitemap XML
- [ ] Sitemap valido y accesible
- [ ] Solo URLs indexables (200, canonical=self)
- [ ] Actualizado (lastmod correcto)
- [ ] Registrado en Search Console
- [ ] Tamano < 50MB, < 50,000 URLs por sitemap

### Meta Robots
- [ ] Paginas importantes son index, follow
- [ ] Paginas thin/duplicate son noindex
- [ ] No hay conflictos robots.txt vs meta robots

### Canonicalizacion
- [ ] Todas las paginas tienen canonical
- [ ] Canonicals apuntan a version correcta (www vs no-www, http vs https)
- [ ] No hay cadenas de canonicals
- [ ] Canonical = URL actual en paginas principales
```

### Arquitectura & Estructura

```markdown
## Checklist Arquitectura

### Estructura de URLs
- [ ] URLs descriptivas y legibles
- [ ] Estructura jerarquica logica
- [ ] Sin parametros innecesarios
- [ ] Consistencia en trailing slashes

### Navegacion
- [ ] Breadcrumbs implementados
- [ ] Menu principal con paginas clave
- [ ] Enlaces internos estrategicos
- [ ] Profundidad maxima 3-4 clicks

### Redirects
- [ ] No hay cadenas de redirects (max 1 hop)
- [ ] 301 para permanentes, 302 para temporales
- [ ] No hay redirect loops
- [ ] Antiguas URLs redirigen correctamente
```

### Performance (Core Web Vitals)

```markdown
## Checklist Core Web Vitals

### LCP (Largest Contentful Paint) - Target < 2.5s
- [ ] Imagenes optimizadas (WebP, compresion)
- [ ] Lazy loading implementado
- [ ] CDN configurado
- [ ] Server response time < 200ms
- [ ] Preload de recursos criticos

### FID/INP (Interactivity) - Target < 100ms
- [ ] JavaScript optimizado y diferido
- [ ] No hay long tasks bloqueantes
- [ ] Third-party scripts minimizados
- [ ] Code splitting implementado

### CLS (Cumulative Layout Shift) - Target < 0.1
- [ ] Dimensiones de imagenes especificadas
- [ ] Fonts con font-display: swap
- [ ] No hay contenido insertado dinamicamente sin espacio reservado
- [ ] Ads con espacio reservado
```

### Seguridad & HTTPS

```markdown
## Checklist Seguridad

- [ ] HTTPS en todo el sitio
- [ ] Certificado SSL valido y no expirado
- [ ] HTTP redirige a HTTPS
- [ ] HSTS configurado
- [ ] Mixed content eliminado
- [ ] Security headers implementados
```

### Contenido & On-Page

```markdown
## Checklist On-Page

### Titles & Metas
- [ ] Title unico por pagina (50-60 chars)
- [ ] Meta description unica (150-160 chars)
- [ ] H1 unico por pagina
- [ ] Jerarquia de headings correcta (H1 > H2 > H3)

### Imagenes
- [ ] Alt text descriptivo en todas las imagenes
- [ ] Nombres de archivo descriptivos
- [ ] Formatos optimizados (WebP preferido)
- [ ] Dimensiones apropiadas

### Schema Markup
- [ ] Organization schema en homepage
- [ ] Breadcrumb schema
- [ ] Article/Product schema segun tipo
- [ ] FAQ schema donde aplique
- [ ] LocalBusiness si aplica
```

## Fase 3: Priorizacion de Tareas

### Modelo de Prioridad

```
Priority = (Impact × Opportunity) / (Effort × Time)
```

### Matriz de Priorizacion

| Prioridad | Criterio | Ejemplos |
|-----------|----------|----------|
| **P0 - Critico** | Bloquea indexacion/ranking | Robots.txt bloqueando, noindex en paginas clave |
| **P1 - Alto** | Impacto significativo, facil fix | Titles duplicados, canonicals rotos |
| **P2 - Medio** | Mejora incremental | Schema faltante, alt texts |
| **P3 - Bajo** | Nice to have | Optimizaciones menores |

### Template de Task Matrix

```markdown
## SEO Task Matrix

| ID | Issue | Paginas Afectadas | Impacto | Esfuerzo | Prioridad | Owner | Status |
|----|-------|-------------------|---------|----------|-----------|-------|--------|
| 001 | Titles duplicados | 45 | Alto | Bajo | P1 | Dev | Pending |
| 002 | LCP > 4s mobile | 120 | Alto | Medio | P1 | Dev | In Progress |
| 003 | Schema faltante | 200 | Medio | Bajo | P2 | SEO | Done |
| ... | ... | ... | ... | ... | ... | ... | ... |
```

## Fase 4: Reporting

### Estructura de Informe

```markdown
## SEO Technical Audit Report

### 1. EXECUTIVE SUMMARY
- Score general: [X]/100
- Issues criticos: [X]
- Quick wins identificados: [X]
- Impacto estimado: +[X]% visibility

### 2. FINDINGS BY CATEGORY

#### Crawling & Indexacion
- Issues encontrados: [X]
- Paginas afectadas: [X]
- Recomendaciones: [lista]

#### Performance
- LCP promedio: [X]s
- CLS promedio: [X]
- Paginas que fallan CWV: [X]%

#### On-Page
- Titles duplicados: [X]
- Metas faltantes: [X]
- Schema coverage: [X]%

### 3. PRIORITIZED ROADMAP
| Fase | Tareas | Timeline | Impacto Esperado |
|------|--------|----------|------------------|
| Quick Wins | [lista] | 1-2 semanas | +5% visibility |
| Fase 1 | [lista] | 1 mes | +15% visibility |
| Fase 2 | [lista] | 2-3 meses | +25% visibility |

### 4. TOOLS & RESOURCES
- Herramientas utilizadas
- Accesos necesarios
- Documentacion de referencia
```

## Metricas Clave a Trackear

| Fuente | Metrica | Frecuencia |
|--------|---------|------------|
| GA4 | Organic Traffic | Semanal |
| Semrush/DataForSEO | Keyword Visibility | Semanal |
| Ahrefs | Backlink Profile Health | Mensual |
| Search Console | CTR & Impressions | Semanal |
| Screaming Frog/Sitebulb | Crawl & Index Ratio | Mensual |
| PageSpeed | Core Web Vitals | Semanal |

## Herramientas Recomendadas

| Herramienta | Uso Principal |
|-------------|---------------|
| **Screaming Frog** | Crawling tecnico |
| **Sitebulb** | Auditorias visuales |
| **Ahrefs** | Backlinks, keywords |
| **Semrush** | Visibility, competencia |
| **DataForSEO** | APIs de datos |
| **Search Console** | Indexacion, clicks |
| **PageSpeed Insights** | Core Web Vitals |
| **Schema Validator** | Structured data |

## Referencias

- Extraido de: SYST_PROMPT_EXP_SEO_498
- Relacionado: geo_process_498AS_expert_system_prompt
