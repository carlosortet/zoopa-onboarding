---
name: event-risk-matrix
description: Framework de gestion de riesgos para eventos incluyendo matriz de riesgos, planes de contingencia por nivel, permisos y seguros obligatorios (Espana). Usar cuando se planifiquen eventos y se necesite evaluar riesgos o crear planes de contingencia.
---

# Event Risk Matrix Skill

Framework completo para identificar, evaluar y mitigar riesgos en eventos.

## Matriz de Riesgos

| Riesgo | Probabilidad | Impacto | Mitigacion |
|--------|--------------|---------|------------|
| **Meteorologia adversa** | Media | Alto | Plan B interior, fecha backup, seguro |
| **Cancelacion speaker principal** | Baja | Alto | Backup confirmado, clausula contrato |
| **Fallo tecnico AV** | Media | Alto | Equipo backup, tecnicos redundantes |
| **No-show asistentes** | Media | Medio | Overbooking 10-15%, comunicacion |
| **Incidente de seguridad** | Baja | Critico | Plan de emergencia, coordinacion |
| **Proveedor falla** | Baja | Alto | Proveedores alternativos identificados |
| **Sobrepaso presupuesto** | Media | Medio | Tracking semanal, contingencia |
| **Problemas de catering** | Baja | Medio | Plan B, multiples proveedores |
| **Problemas de acceso/parking** | Media | Medio | Comunicacion clara, alternativas |
| **Fallo de internet/conectividad** | Media | Alto | Linea backup, 4G/5G |

## Evaluacion de Riesgos

### Escala de Probabilidad

| Nivel | Descripcion | Criterio |
|-------|-------------|----------|
| **Alta** | Muy probable | >50% de ocurrencia |
| **Media** | Posible | 20-50% de ocurrencia |
| **Baja** | Improbable | <20% de ocurrencia |

### Escala de Impacto

| Nivel | Descripcion | Criterio |
|-------|-------------|----------|
| **Critico** | Cancela evento | Seguridad, legal, reputacional severo |
| **Alto** | Afecta significativamente | Experiencia degradada, costes altos |
| **Medio** | Afecta parcialmente | Molestias, costes moderados |
| **Bajo** | Minimo impacto | Inconvenientes menores |

### Matriz de Prioridad

|  | Impacto Bajo | Impacto Medio | Impacto Alto | Impacto Critico |
|--|--------------|---------------|--------------|-----------------|
| **Prob. Alta** | Monitorear | Mitigar | Mitigar urgente | Plan A+B+C |
| **Prob. Media** | Aceptar | Monitorear | Mitigar | Plan A+B |
| **Prob. Baja** | Aceptar | Aceptar | Monitorear | Plan A+B |

## Protocolo de Contingencias por Nivel

### NIVEL 1: Incidencia Menor

```markdown
## Caracteristicas
- No afecta experiencia general
- Resolucion rapida posible
- Sin escalado necesario

## Protocolo
1. Gestion por equipo de produccion on-site
2. Resolucion inmediata
3. Documentar para post-evento
4. No comunicar externamente

## Ejemplos
- Retraso menor en programa (<15 min)
- Fallo de micro individual
- Catering llegando tarde
- Problema con acreditacion individual
```

### NIVEL 2: Incidencia Media

```markdown
## Caracteristicas
- Puede afectar parte del evento
- Requiere decision rapida
- Posible impacto en experiencia

## Protocolo
1. Escalar a Director de Produccion inmediatamente
2. Evaluar opciones (Plan A, B)
3. Comunicacion interna al equipo
4. Activar plan B especifico si necesario
5. Documentar decisiones y tiempos

## Ejemplos
- Fallo de sistema AV completo
- No-show de speaker secundario
- Problema con catering (alergias, cantidad)
- Incidente menor de seguridad
- Sobreventa/problemas de aforo
```

### NIVEL 3: Incidencia Critica

```markdown
## Caracteristicas
- Afecta evento completo
- Posible cancelacion/suspension
- Impacto reputacional

## Protocolo
1. Escalar a cliente y direccion INMEDIATAMENTE
2. Activar protocolos de emergencia
3. Evaluar suspension/cancelacion
4. Comunicacion externa si necesario
5. Coordinar con autoridades si aplica
6. Documentacion exhaustiva
7. Gestion de crisis post-evento

## Ejemplos
- Emergencia medica grave
- Amenaza de seguridad
- Cancelacion speaker principal sin backup
- Fallo estructural del venue
- Condiciones meteorologicas extremas
```

## Permisos Necesarios (Espana)

| Permiso | Entidad | Timing | Notas |
|---------|---------|--------|-------|
| **Ocupacion via publica** | Ayuntamiento | 30-60 dias antes | Si hay elementos exteriores |
| **Actividad extraordinaria** | Ayuntamiento | 15-30 dias antes | Eventos en espacios no habituales |
| **Ruido/contaminacion acustica** | Medio Ambiente | 15-30 dias antes | Si musica amplificada |
| **Licencia de bar/alcohol** | Ayuntamiento | 30 dias antes | Si se sirve alcohol |
| **Manipulacion de alimentos** | Sanidad | - | Proveedor debe tener certificacion |
| **Bomberos/seguridad** | Proteccion Civil | 15-30 dias antes | Aforo >500 personas |
| **Montaje estructuras** | Ayuntamiento + tecnico | Segun tamano | Escenarios, carpas grandes |
| **SGAE/derechos musica** | SGAE | 15 dias antes | Si musica con derechos |
| **Drones** | AESA | Variable | Si grabacion con drones |

## Seguros Obligatorios

| Seguro | Cobertura Minima | Cuando es Obligatorio |
|--------|-----------------|----------------------|
| **Responsabilidad Civil** | 600.000€ - 1.000.000€ | Eventos publicos |
| **Cancelacion** | Coste total del evento | Recomendado eventos grandes |
| **Accidentes** | Segun asistentes | Actividades de riesgo |
| **Equipos** | Valor del material | AV, escenografia cara |
| **Meteorologico** | Coste del evento | Eventos outdoor |

## Plan de Emergencia Template

```markdown
## Plan de Emergencia [Evento]

### 1. CADENA DE MANDO
- Director de Emergencia: [Nombre] - [Telefono]
- Coordinador Seguridad: [Nombre] - [Telefono]
- Enlace con Autoridades: [Nombre] - [Telefono]

### 2. CONTACTOS DE EMERGENCIA
- Emergencias: 112
- Policia Local: [Numero]
- Bomberos: [Numero]
- Hospital mas cercano: [Nombre] - [Direccion]
- Ambulancia contratada: [Empresa] - [Telefono]

### 3. PROTOCOLOS

#### Evacuacion
- Salidas de emergencia: [Ubicaciones]
- Punto de encuentro: [Ubicacion]
- Responsables de zona: [Lista]
- Capacidad maxima: [Numero]

#### Emergencia Medica
1. Alertar a equipo medico on-site
2. Despejar area
3. Llamar 112 si es grave
4. Acompanar a afectado
5. Documentar incidente

#### Incendio
1. Activar alarma
2. Llamar 112
3. Iniciar evacuacion
4. NO usar ascensores
5. Punto de encuentro

#### Amenaza de Seguridad
1. Alertar a seguridad privada
2. Contactar policia (091/092)
3. Evaluar evacuacion
4. Mantener calma
5. Seguir instrucciones autoridades

### 4. COMUNICACION EN CRISIS
- Portavoz designado: [Nombre]
- Mensaje base: [Template]
- Canales: [Lista]
- Quien NO habla con medios: [Todos excepto portavoz]
```

## Checklist Pre-Evento Riesgos

```markdown
## Verificacion D-7

### Permisos y Seguros
- [ ] Todos los permisos aprobados
- [ ] Polizas de seguro vigentes
- [ ] Copias disponibles on-site

### Seguridad
- [ ] Plan de emergencia revisado
- [ ] Equipo de seguridad briefeado
- [ ] Rutas de evacuacion senalizadas
- [ ] Punto medico operativo

### Proveedores
- [ ] Todos confirmados
- [ ] Proveedores backup identificados
- [ ] Contactos de emergencia actualizados

### Comunicacion
- [ ] Cadena de mando clara
- [ ] Walkies/comunicacion interna probada
- [ ] Contactos de emergencia distribuidos

### Contingencias
- [ ] Plan B meteo revisado (si outdoor)
- [ ] Backup AV disponible
- [ ] Speaker alternativo confirmado (si aplica)
```

## Template de Riesgos por Evento

```markdown
## Matriz de Riesgos - [Nombre Evento]

### DATOS DEL EVENTO
- Fecha: [XX/XX/XXXX]
- Venue: [Nombre]
- Aforo: [Numero]
- Interior/Exterior: [X]

### RIESGOS IDENTIFICADOS

| ID | Riesgo | P | I | Mitigacion | Responsable | Status |
|----|--------|---|---|------------|-------------|--------|
| R01 | [Riesgo] | A/M/B | C/A/M/B | [Accion] | [Nombre] | [OK/Pendiente] |
| R02 | ... | ... | ... | ... | ... | ... |

### PLANES DE CONTINGENCIA ACTIVOS
1. [Plan A]: [Descripcion]
2. [Plan B]: [Descripcion]

### REVISION
- Ultima revision: [Fecha]
- Proxima revision: [Fecha]
- Responsable: [Nombre]
```

## Referencias

- Extraido de: system_prompt_events_production_zoopa
- Relacionado: system_prompt_director_produccion_zoopa, system_prompt_zoopa_legal
