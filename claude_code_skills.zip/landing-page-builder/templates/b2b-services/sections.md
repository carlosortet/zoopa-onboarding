# B2B Services Landing Page Sections

Estructura optimizada para lead generation de servicios profesionales B2B.

## Orden de Secciones

```
1. Hero          → Propuesta de valor + CTA contacto
2. Problem       → Dolor del cliente (PAS approach)
3. Solution      → Cómo resolvemos el problema
4. Process       → Metodología en 3-5 pasos
5. Results       → Casos de éxito / métricas
6. Services      → Detalle de servicios ofrecidos
7. Why Us        → Diferenciadores y credenciales
8. FAQ           → Preguntas frecuentes
9. Final CTA     → Contacto / consulta gratuita
10. Footer       → Info empresa + legal
```

## Sección 1: Hero

```
┌─────────────────────────────────────────────────────┐
│  [Tag: Tipo de servicio]                            │
│                                                     │
│  HEADLINE: Resultado que consigues (6-12 palabras)  │
│                                                     │
│  Subheadline: Problema + Solución + Para quién      │
│                                                     │
│  [Sol·licita Consulta Gratuïta]  [Veure Casos d'Èxit]│
│                                                     │
│  Trusted by: [Logo 1] [Logo 2] [Logo 3] [Logo 4]    │
└─────────────────────────────────────────────────────┘
```

**Foco en resultado**, no en descripción del servicio.

## Sección 2: Problem

```
┌─────────────────────────────────────────────────────┐
│  Title: "El repte que afrontes"                     │
│                                                     │
│  ┌─────────────────────────────────────────────────┐│
│  │ Descripción empática del problema del cliente   ││
│  │ que conecta con su realidad diaria...          ││
│  └─────────────────────────────────────────────────┘│
│                                                     │
│  Pain Points:                                       │
│  ✗ Pain point 1                                    │
│  ✗ Pain point 2                                    │
│  ✗ Pain point 3                                    │
│  ✗ Pain point 4                                    │
│                                                     │
│  "Si t'identifiques amb això, podem ajudar-te."    │
└─────────────────────────────────────────────────────┘
```

**PAS - Problem phase**: Nombrar y amplificar el dolor.

## Sección 3: Solution

```
┌─────────────────────────────────────────────────────┐
│  Title: "Com ho resolem"                            │
│                                                     │
│  Descripción de alto nivel de la solución...        │
│                                                     │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐             │
│  │ ✓       │  │ ✓       │  │ ✓       │             │
│  │ Pilar 1 │  │ Pilar 2 │  │ Pilar 3 │             │
│  │         │  │         │  │         │             │
│  └─────────┘  └─────────┘  └─────────┘             │
│                                                     │
│  "El resultat: [outcome específico]"                │
└─────────────────────────────────────────────────────┘
```

**PAS - Solution phase**: 3 pilares de la solución.

## Sección 4: Process

```
┌─────────────────────────────────────────────────────┐
│  Title: "Com treballem amb tu"                      │
│                                                     │
│  (1)────────(2)────────(3)────────(4)              │
│                                                     │
│  Descobriment → Estratègia → Execució → Optimització│
│                                                     │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐│
│  │ Audit   │  │ Roadmap │  │ Implement│  │ Measure ││
│  │ inicial │  │ custom  │  │ + Launch │  │ + Iterate│
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘│
│                                                     │
│  "Procés clar, resultats mesurables."              │
└─────────────────────────────────────────────────────┘
```

**Metodología clara** que reduce incertidumbre.

## Sección 5: Results

```
┌─────────────────────────────────────────────────────┐
│  Title: "Resultats que parlen"                      │
│                                                     │
│  ┌─────────────────────────────────────────────────┐│
│  │ CASE STUDY 1                                    ││
│  │ "Client X va aconseguir Y en Z temps"           ││
│  │ Mètriques: +150% conversió, -40% CAC           ││
│  │ [Llegir Cas Complet]                            ││
│  └─────────────────────────────────────────────────┘│
│                                                     │
│  ┌─────────────────────────────────────────────────┐│
│  │ CASE STUDY 2                                    ││
│  │ ...                                             ││
│  └─────────────────────────────────────────────────┘│
│                                                     │
│  Métricas globales:                                 │
│  [+X%] [€Y] [Z clients]                            │
└─────────────────────────────────────────────────────┘
```

**Casos de éxito** con métricas específicas.

## Sección 6: Services

```
┌─────────────────────────────────────────────────────┐
│  Title: "Els nostres serveis"                       │
│                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────┐│
│  │ Servei 1     │  │ Servei 2     │  │ Servei 3   ││
│  │              │  │              │  │            ││
│  │ • Inclou A   │  │ • Inclou A   │  │ • Inclou A ││
│  │ • Inclou B   │  │ • Inclou B   │  │ • Inclou B ││
│  │ • Inclou C   │  │ • Inclou C   │  │ • Inclou C ││
│  │              │  │              │  │            ││
│  │ [Més Info]   │  │ [Més Info]   │  │ [Més Info] ││
│  └──────────────┘  └──────────────┘  └────────────┘│
│                                                     │
│  "Solucions adaptades a les teves necessitats."     │
└─────────────────────────────────────────────────────┘
```

**Detalle de servicios** con lo que incluye cada uno.

## Sección 7: Why Us

```
┌─────────────────────────────────────────────────────┐
│  Title: "Per què nosaltres"                         │
│                                                     │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐│
│  │ +10     │  │ +50     │  │ €X M    │  │ 98%     ││
│  │ anys    │  │ clients │  │ gestionats│ │ retenció││
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘│
│                                                     │
│  Credenciales:                                      │
│  • Certificació 1                                   │
│  • Partner de X                                     │
│  • Reconeixement Y                                  │
│                                                     │
│  Diferenciadores:                                   │
│  ✓ Diferenciador 1                                 │
│  ✓ Diferenciador 2                                 │
│  ✓ Diferenciador 3                                 │
└─────────────────────────────────────────────────────┘
```

**Credenciales + diferenciadores** que generan confianza.

## Sección 8: FAQ

```
┌─────────────────────────────────────────────────────┐
│  Title: "Preguntes freqüents"                       │
│                                                     │
│  ▸ Quant costa el servei?                          │
│  ▸ Quin és el temps d'implementació?               │
│  ▸ Quins resultats puc esperar?                    │
│  ▸ Com mesureu l'èxit?                             │
│  ▸ Oferiu garantia de resultats?                   │
│  ▸ Treballeu amb empreses del meu sector?          │
└─────────────────────────────────────────────────────┘
```

**Preguntas típicas B2B** sobre precio, tiempo, resultados.

## Sección 9: Final CTA

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  Title: "Preparat per [resultado]?"                 │
│                                                     │
│  "Agenda una consulta gratuïta de 30 minuts.        │
│   Analitzarem el teu cas i et donarem               │
│   recomanacions accionables."                       │
│                                                     │
│  [Sol·licita Consulta Gratuïta]                     │
│                                                     │
│  Opcional: Form inline con campos básicos           │
│  [Nom] [Email] [Empresa] [Missatge]                │
│  [Enviar]                                           │
│                                                     │
│  "Sense compromís · Resposta en 24h"                │
└─────────────────────────────────────────────────────┘
```

**Lead capture** con valor inmediato (consulta gratuita).

## Sección 10: Footer

```
┌─────────────────────────────────────────────────────┐
│  [Logo]                                             │
│                                                     │
│  Sobre nosaltres | Serveis | Casos d'Èxit | Blog   │
│                                                     │
│  Contacte:                                          │
│  📧 email@empresa.com                               │
│  📞 +34 XXX XXX XXX                                │
│  📍 Adreça, Ciutat                                 │
│                                                     │
│  [LinkedIn] [Twitter]                               │
│                                                     │
│  © 2026 Empresa. Política de Privacitat | Legal    │
└─────────────────────────────────────────────────────┘
```

---

## Diferencias clave vs. otras LP

| Aspecto | SaaS | Event | B2B Services |
|---------|------|-------|--------------|
| Foco | Producto | Asistencia | Relación |
| CTA principal | Trial/Demo | Registro | Consulta |
| Proof | Testimonials | Speakers | Case Studies |
| Urgencia | Features | Aforo | Resultados |
| Detalle | Features | Agenda | Metodología |
| Conversión | Signup | Register | Lead form |
