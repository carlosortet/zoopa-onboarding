# Event Landing Page Sections

Basado en patrón RADAR landing. 9 secciones optimizadas para registro de eventos.

## Orden de Secciones

```
1. Navigation    → Logo + CTA de registro (sticky)
2. Hero          → Nombre evento + fecha + lugar + CTAs
3. Audience      → "Para quién es" (4 categorías)
4. Discover      → Qué aprenderás (stats/datos impactantes)
5. Speakers      → 4 speakers con foto y tema
6. Benefits      → Qué incluye (tiers si aplica)
7. Details       → Cuándo, dónde, precio, aforo
8. Final CTA     → Cierre con urgencia
9. Footer        → Organizador + info legal
```

## Sección 1: Navigation (Sticky)

```
┌─────────────────────────────────────────────────────┐
│  [Logo Organizador]                   [CTA: Inscriu-te] │
└─────────────────────────────────────────────────────┘
```

**Características:**
- Fixed al top
- Fondo semi-transparente con blur
- CTA siempre visible

## Sección 2: Hero

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│           [Tag: Organizador presenta]               │
│                                                     │
│                    RADAR                            │
│                    2026                             │
│                                                     │
│  "Les tendències i innovacions, aterrades a Catalunya" │
│  "Tu, segur que estàs preparat?"                    │
│                                                     │
│  📅 21 gener 2026  ⏰ 18:30h  📍 Museu del Disseny  │
│                                                     │
│  [SÍ! VULL ASSISTIR]  [VULL L'EBOOK]               │
│                                                     │
│  Aforament presencial: 60 places                    │
└─────────────────────────────────────────────────────┘
```

**Elementos clave:**
- Nombre evento grande y bold
- Año/edición en lighter weight
- Hook emocional ("segur que estàs preparat?")
- Info esencial: fecha, hora, lugar
- Dual CTA pattern
- Nota de escasez (aforo)

## Sección 3: Audience

```
┌─────────────────────────────────────────────────────┐
│  "Imprescindible si ets professional o estudiant de:" │
│                                                     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌────────┐ │
│  │Creativitat│ │Màrqueting│ │Publicitat│ │Comunicació│
│  └──────────┘ └──────────┘ └──────────┘ └────────┘ │
│                                                     │
│  "Tant si comences com si portes 20 anys al sector." │
└─────────────────────────────────────────────────────┘
```

**Grid de 4 categorías** de audiencia + nota inclusiva.

## Sección 4: Discover

```
┌─────────────────────────────────────────────────────┐
│  Title: "Les dades que canviaran com treballes"     │
│                                                     │
│  ┌─────────────────────────────────────────────────┐│
│  │ "El consumidor ha canviat"                      ││
│  │ • 47% dels joves prefereixen IA vs humans       ││
│  │ • 46% pagarà més per estabilitat               ││
│  │ • 77% vol productes que millorin ànim          ││
│  └─────────────────────────────────────────────────┘│
│                                                     │
│  ┌─────────────────────────────────────────────────┐│
│  │ "La professió ha canviat"                       ││
│  │ • 48% menors de 25 temen perdre feina per IA   ││
│  │ • Si no surts a ChatGPT... no existeixes       ││
│  │ • 30% agències petites tancaran en 18 mesos    ││
│  └─────────────────────────────────────────────────┘│
│                                                     │
│  [CTA Repetido]                                     │
└─────────────────────────────────────────────────────┘
```

**Datos impactantes** que crean urgencia y FOMO.

## Sección 5: Speakers

```
┌─────────────────────────────────────────────────────┐
│  Tag: "4 Experts, 4 Perspectives"                   │
│                                                     │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐│
│  │  (foto) │  │  (foto) │  │  (foto) │  │  (foto) ││
│  │ Nombre  │  │ Nombre  │  │ Nombre  │  │ Nombre  ││
│  │ Tema    │  │ Tema    │  │ Tema    │  │ Tema    ││
│  │ @Company│  │ @Company│  │ @Company│  │ @Company││
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘│
└─────────────────────────────────────────────────────┘
```

**Speaker cards:**
- Foto (grayscale, circular)
- Nombre completo
- Tema de la charla
- Rol @ Empresa

## Sección 6: Benefits

```
┌─────────────────────────────────────────────────────┐
│  Title: "Més que un event"                          │
│                                                     │
│  ┌────────────────────┐  ┌────────────────────────┐│
│  │ ACCÉS IMMEDIAT     │  │ TOT L'ANTERIOR +       ││
│  │ (Tothom)           │  │ (Col·legiats)          ││
│  │                    │  │                        ││
│  │ ✓ Ebook gratuït    │  │ ✓ Summary post-event   ││
│  │ ✓ Sessió presencial│  │ ✓ Q&A exclusiu         ││
│  │ ✓ 60 min contingut │  │ ✓ Respostes personals  ││
│  │ ✓ 20 min networking│  │                        ││
│  └────────────────────┘  └────────────────────────┘│
│                                                     │
│  [CTA]                                              │
└─────────────────────────────────────────────────────┘
```

**Dos tiers** si hay diferenciación (miembros vs. público general).

## Sección 7: Details

```
┌─────────────────────────────────────────────────────┐
│  Title: "Tot el que necessites saber"               │
│                                                     │
│  📅 QUAN                    📍 ON                   │
│  Dimecres, 21 gener 2026   Museu del Disseny BCN   │
│  18:30h - 20:30h           Plaça de les Glòries    │
│                                                     │
│  💰 PREU                    👥 AFORAMENT            │
│  Entrada gratuïta          60 places presencials   │
│  Ebook gratuït             "Registra't aviat"      │
└─────────────────────────────────────────────────────┘
```

**4 bloques** con información práctica esencial.

## Sección 8: Final CTA

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  Title: "No et quedis sense el contingut"           │
│                                                     │
│  "Encara que no puguis venir presencialment,        │
│   tindràs les tendències que definiran el 2026."    │
│                                                     │
│  [SÍ! VULL ASSISTIR]  [VULL L'EBOOK]               │
│                                                     │
│  Només 60 places presencials · Entrada gratuïta     │
└─────────────────────────────────────────────────────┘
```

**Urgencia + alternativa** para quienes no pueden asistir.

## Sección 9: Footer

```
┌─────────────────────────────────────────────────────┐
│  [Logo Organizador]                                 │
│  "Slogan organizador"                               │
│                                                     │
│  Organitza: [Comité/Área]                           │
│  Web: [url]                                         │
│                                                     │
│  © 2026 [Organización]. Tots els drets reservats.  │
└─────────────────────────────────────────────────────┘
```

---

## Diferencias clave vs. SaaS Landing

| Aspecto | SaaS | Event |
|---------|------|-------|
| Hero | Producto + transformación | Evento + fecha/lugar |
| CTAs | Trial/Demo | Asistir/Contenido |
| Social proof | Testimonials | Speakers |
| Urgencia | Beneficio | Aforo limitado |
| Benefits | Features | What's included |
| FAQ | Producto | Logística |
