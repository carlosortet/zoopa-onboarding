# SaaS/Product Landing Page Sections

Basado en patrón SAM landing. 10 secciones optimizadas para conversión de producto/SaaS.

## Orden de Secciones

```
1. Hero          → Propuesta de valor + CTA principal
2. Benefits      → "Qué hace por ti" (3-4 cards)
3. Differential  → "Por qué diferente" (4-5 items)
4. How It Works  → Proceso en 3 pasos
5. Features      → Grid de capacidades (8-9 items)
6. Testimonials  → 3 testimonios de clientes
7. Before/After  → Comparación transformación
8. Use Cases     → Para quién es (5-6 personas)
9. FAQ           → 6-8 preguntas frecuentes
10. Final CTA    → Cierre con CTAs repetidos
```

## Sección 1: Hero

```
┌─────────────────────────────────────────────────────┐
│  [Tag: Nombre Producto — Tagline]                   │
│                                                     │
│  HEADLINE: Transformación en 6-12 palabras          │
│                                                     │
│  Subheadline: Problema + Solución (20-40 palabras)  │
│                                                     │
│  [CTA Primario]  [CTA Secundario]  [CTA Terciario]  │
│                                                     │
│  Opcional: "Más de X empresas confían en nosotros"  │
└─────────────────────────────────────────────────────┘
```

**Elementos requeridos:**
- Tag con nombre producto
- Headline con beneficio principal
- Subheadline con PAS (Problem-Agitate-Solution)
- 2-3 CTAs (primario + secundarios)

## Sección 2: Benefits

```
┌─────────────────────────────────────────────────────┐
│  [Tag: "Què fa [Producto] per tu"]                  │
│  Title: "Control real del [beneficio principal]"    │
│                                                     │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐             │
│  │ 📊      │  │ 🎯      │  │ 🔬      │             │
│  │ Benefit │  │ Benefit │  │ Benefit │             │
│  │ 1       │  │ 2       │  │ 3       │             │
│  └─────────┘  └─────────┘  └─────────┘             │
│                                                     │
│  Opcional: Showcase de métricas reales              │
└─────────────────────────────────────────────────────┘
```

**3-4 benefit cards** con:
- Icono emoji
- Título del beneficio
- Descripción orientada al cliente (2-3 frases)

## Sección 3: Differential

```
┌─────────────────────────────────────────────────────┐
│  [Tag: "Per què [Producto] és diferent"]            │
│  Title: "De [estado actual] a [estado deseado]"     │
│                                                     │
│  ┃ Diferencial 1: Título                           │
│  ┃ Descripción de cómo es diferente...            │
│                                                     │
│  ┃ Diferencial 2: Título                           │
│  ┃ Descripción...                                  │
│                                                     │
│  (4-5 items con borde lateral de acento)           │
└─────────────────────────────────────────────────────┘
```

## Sección 4: How It Works

```
┌─────────────────────────────────────────────────────┐
│  [Tag: "Com funciona [Producto]"]                   │
│  Title: "De [inicio] a [resultado] en 3 passos"     │
│                                                     │
│  ┌───────┐      ┌───────┐      ┌───────┐           │
│  │  (1)  │  →   │  (2)  │  →   │  (3)  │           │
│  │ Paso  │      │ Paso  │      │ Paso  │           │
│  │ Verbo │      │ Verbo │      │ Verbo │           │
│  └───────┘      └───────┘      └───────┘           │
│                                                     │
│  Opcional: Integration highlight box                │
└─────────────────────────────────────────────────────┘
```

## Sección 5: Features

```
┌─────────────────────────────────────────────────────┐
│  [Tag: "Feature Set"]                               │
│  Title: "Capacitats completes de [Producto]"        │
│                                                     │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐             │
│  │Feature 1│  │Feature 2│  │Feature 3│             │
│  ├─────────┤  ├─────────┤  ├─────────┤             │
│  │Feature 4│  │Feature 5│  │Feature 6│             │
│  ├─────────┤  ├─────────┤  ├─────────┤             │
│  │Feature 7│  │Feature 8│  │Feature 9│             │
│  └─────────┘  └─────────┘  └─────────┘             │
└─────────────────────────────────────────────────────┘
```

**Grid 3x3** con título corto + descripción breve.

## Sección 6: Testimonials

```
┌─────────────────────────────────────────────────────┐
│  [Tag: "Testimonis"]                                │
│  Title: "Què diuen els nostres clients"             │
│                                                     │
│  "Quote 1..."          "Quote 2..."                 │
│  — Rol, Empresa         — Rol, Empresa              │
│                                                     │
│                "Quote 3..."                         │
│                — Rol, Empresa                       │
└─────────────────────────────────────────────────────┘
```

## Sección 7: Before/After

```
┌─────────────────────────────────────────────────────┐
│  [Tag: "Abans i Després"]                           │
│  Title: "Abans i després de [Producto]"             │
│                                                     │
│  ABANS (❌ rojo)        DESPRÉS (✓ verde)           │
│  ├─ Pain point 1        ├─ Benefit 1               │
│  ├─ Pain point 2        ├─ Benefit 2               │
│  ├─ Pain point 3        ├─ Benefit 3               │
│  └─ ...                 └─ ...                     │
│                                                     │
│  "De la incertesa a la ciència."                   │
│  "De l'aposta al control."                         │
└─────────────────────────────────────────────────────┘
```

## Sección 8: Use Cases

```
┌─────────────────────────────────────────────────────┐
│  [Tag: "Per a qui és [Producto]"]                   │
│  Title: "Casos d'ús"                                │
│                                                     │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐          │
│  │ Persona 1│  │ Persona 2│  │ Persona 3│          │
│  ├──────────┤  ├──────────┤  ├──────────┤          │
│  │ Persona 4│  │ Persona 5│  │ Persona 6│          │
│  └──────────┘  └──────────┘  └──────────┘          │
└─────────────────────────────────────────────────────┘
```

## Sección 9: FAQ

```
┌─────────────────────────────────────────────────────┐
│  [Tag: "FAQ"]                                       │
│  Title: "Preguntes freqüents"                       │
│                                                     │
│  ▸ Pregunta 1?                                      │
│    Respuesta...                                     │
│                                                     │
│  ▸ Pregunta 2?                                      │
│    Respuesta...                                     │
│                                                     │
│  (6-8 FAQs expandibles)                             │
└─────────────────────────────────────────────────────┘
```

## Sección 10: Final CTA

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  Title: "Converteix [problema] en [solución]"       │
│                                                     │
│  Subtitle: "Sense [Producto], [pain]. Amb [P], X."  │
│                                                     │
│  [CTA Primario]  [CTA Secundario]  [CTA Terciario]  │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## Ejemplo de Implementación: SAM

| Sección | Contenido Real |
|---------|----------------|
| Hero | "La tecnologia que converteix el GEO en ciència exacta" |
| Benefits | Matching Score + Predicció + Insights quirúrgics |
| Differential | Cross-Model, Persona Affinity, Heatmaps |
| How It Works | Defineix → Confronta → Optimitza |
| Features | 9 capacidades en grid |
| Testimonials | Head of Content, CMO, AI Director |
| Before/After | 8 vs 8 items |
| Use Cases | 6 personas target |
| FAQ | 8 preguntas |
| Final CTA | Repetir propuesta |
