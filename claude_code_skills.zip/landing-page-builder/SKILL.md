---
name: landing-page-builder
description: Crea landing pages de alta conversión con copys optimizados y estructura semántica. Usar cuando el usuario necesite crear una landing page para: (1) Productos o SaaS (conversiones, signups, demos), (2) Eventos (registros, asistencia), (3) Servicios B2B (lead generation). Soporta CA/ES/EN con ficheros JSON por idioma. Aplica fórmulas de copywriting (PAS, AIDA, PASTOR) y patrones de optimización de conversión. Output: Markdown + HTML semántico + CSS externo con variables.
---

# Landing Page Builder

Crea landing pages optimizadas para conversión con copys profesionales en múltiples idiomas.

## Tipos de Landing Page

Detectar el tipo según el request del usuario:

| Tipo | Objetivo | Secciones | Template |
|------|----------|-----------|----------|
| **SaaS/Product** | Signups, demos, compras | 10 | `templates/saas-product/` |
| **Event** | Registros, asistencia | 9 | `templates/event/` |
| **B2B Services** | Lead generation | 8-10 | `templates/b2b-services/` |

## Workflow

### 1. Recopilar Información

Antes de generar, preguntar al usuario:

**Obligatorio:**
- Nombre del producto/servicio/evento
- Objetivo principal (signup, registro, contacto, compra)
- Target audience (quiénes son, qué necesitan)
- Problema principal que resuelve
- 3-5 beneficios clave
- Diferenciadores vs alternativas
- Idiomas necesarios (CA, ES, EN)

**Opcional:**
- Colores de marca (primary, secondary, accent)
- Testimonios o social proof
- FAQs existentes
- Pricing

### 2. Seleccionar Fórmula de Copy

Ver `references/copywriting-formulas.md` para elegir:

| Audiencia | Fórmula |
|-----------|---------|
| Desconocen el problema | AIDA |
| Conocen el dolor | PAS |
| Conocen soluciones | FAB |
| Alta consideración | PASTOR |

### 3. Generar Contenido

Para cada sección, seguir las guías de `references/section-guidelines.md`:

**Hero**: Headline 6-12 palabras + Subheadline 20-40 palabras + CTA primario/secundario

**Benefits**: 3-4 cards orientadas al cliente (no features)

**Differential**: 4-5 puntos vs alternativas

**How It Works**: 3 pasos con verbos de acción

**Testimonials**: 3 quotes con resultados específicos

**FAQ**: 6-8 preguntas que resuelven objeciones

**Final CTA**: Repetir propuesta de valor + CTAs

### 4. Estructura de Output

Generar archivos organizados:

```
output/
├── content/
│   ├── content-ca.json    # Contenido estructurado catalán
│   ├── content-es.json    # Contenido estructurado español
│   └── content-en.json    # Contenido estructurado inglés
├── index_ca.html          # HTML catalán
├── index_es.html          # HTML español
├── index_en.html          # HTML inglés
└── styles.css             # CSS con variables de marca
```

### 5. JSON Content Structure

Usar estructura de `templates/[tipo]/content-template.json`:

```json
{
  "lang": "ca",
  "meta": { "title": "", "description": "", "keywords": "" },
  "hero": { "tag": "", "title": "", "subtitle": "", "buttons": [] },
  "sections": {
    "benefits": { "tag": "", "title": "", "features": [] },
    "howItWorks": { "tag": "", "title": "", "steps": [] },
    "testimonials": { "tag": "", "title": "", "items": [] },
    "faq": { "tag": "", "title": "", "items": [] },
    "finalCTA": { "title": "", "subtitle": "", "buttons": [] }
  }
}
```

### 6. HTML Semantic Structure

```html
<!DOCTYPE html>
<html lang="ca">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{{title}}</title>
  <meta name="description" content="{{description}}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <nav class="nav">...</nav>
  <section id="hero" class="hero">...</section>
  <section id="benefits" class="section">...</section>
  <!-- ... more sections ... -->
  <section id="cta" class="section cta-final">...</section>
  <footer class="footer">...</footer>
</body>
</html>
```

### 7. CSS con Variables de Marca

Usar `assets/css/variables.css` como base y personalizar:

```css
:root {
  --color-primary: #0066FF;      /* Ajustar a marca */
  --color-secondary: #00D4FF;    /* Ajustar a marca */
  --color-dark: #0A0E27;
  --color-light: #FFFFFF;
}
```

## Referencias

- **Fórmulas de copy**: Ver `references/copywriting-formulas.md`
- **Guías por sección**: Ver `references/section-guidelines.md`
- **Optimización CTA**: Ver `references/cta-optimization.md`

## Templates por Tipo

- **SaaS/Product**: Ver `templates/saas-product/sections.md`
- **Event**: Ver `templates/event/sections.md`
- **B2B Services**: Ver `templates/b2b-services/sections.md`

## Quality Checklist

Antes de entregar, verificar:

- [ ] Hero comunica valor en 5 segundos
- [ ] Headline under 12 palabras
- [ ] Benefits orientados al cliente (no features)
- [ ] CTAs con verbos de acción
- [ ] Social proof específico y creíble
- [ ] FAQ resuelve objeciones principales
- [ ] Mobile-responsive verificado
- [ ] Todos los idiomas consistentes
