# Optimización de CTAs

## Fórmulas de Texto para Botones

### 1. Acción + Valor

```
[Verbo] + [Resultado/Beneficio]

✓ "Valida els teus Continguts"
✓ "Sol·licita Demo Gratuïta"
✓ "Descarrega l'Ebook"
✓ "Comença la Prova"
```

### 2. Primera Persona

```
"Vull [Acción/Resultado]"

✓ "Vull Assistir"
✓ "Vull l'Ebook"
✓ "Vull Veure Com Funciona"
✓ "Comença la meva prova"
```

### 3. Urgencia + Acción

```
[Temporal] + [Acción]

✓ "Reserva Ara"
✓ "Comença Avui"
✓ "Últimes Places"
✓ "Registra't Abans del [Data]"
```

---

## Dual CTA Pattern

Patrón de RADAR landing - ofrecer dos opciones:

```
┌────────────────────┬────────────────────┐
│  ACCIÓN PRINCIPAL  │  ALTERNATIVA       │
│  (Alto compromiso) │  (Bajo compromiso) │
├────────────────────┼────────────────────┤
│ "SÍ! VULL ASSISTIR"│ "VULL L'EBOOK"    │
│ "Comença Prova"    │ "Veure Demo"       │
│ "Contracta Ara"    │ "Parlar amb Expert"│
└────────────────────┴────────────────────┘
```

### Cuándo Usar

```
✓ Cuando hay múltiples niveles de compromiso
✓ Para capturar leads que no están listos para comprar
✓ Eventos: asistir vs. recibir contenido
✓ SaaS: trial vs. demo guiada
```

---

## Placement Strategy

### Above the Fold

```
HERO
├── Primary CTA: Alto contraste, destacado
├── Secondary CTA: Menor prominencia
└── Posición: Centro o izquierda (F-pattern)
```

### After Value Sections

```
Repetir CTA después de:
├── Benefits section
├── Testimonials section
├── Before/After section
└── Antes del footer
```

### Sticky Navigation

```
NAV (fijo)
└── CTA pequeño siempre visible: "Inscriu-te"
```

---

## Diseño de Botones

### Primary Button

```css
.btn-primary {
  background: linear-gradient(135deg, #0066FF, #00D4FF);
  color: white;
  padding: 16px 32px;
  border-radius: 8px;
  font-weight: 600;
  box-shadow: 0 4px 20px rgba(0, 102, 255, 0.4);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 30px rgba(0, 102, 255, 0.6);
}
```

### Secondary Button

```css
.btn-secondary {
  background: transparent;
  color: white;
  border: 1px solid rgba(255, 255, 255, 0.2);
  padding: 16px 32px;
  border-radius: 8px;
}

.btn-secondary:hover {
  background: rgba(255, 255, 255, 0.1);
  border-color: rgba(255, 255, 255, 0.3);
}
```

### Tamaños

| Contexto | Padding | Font Size |
|----------|---------|-----------|
| Hero CTA | 16px 32px | 16px |
| Section CTA | 14px 28px | 15px |
| Nav CTA | 10px 20px | 14px |

---

## Triggers Psicológicos

### 1. Escasez

```
"60 places disponibles"
"Últimes 10 entrades"
"Fins el 31 de gener"
"Edició limitada"
```

### 2. Social Proof Adyacente

```
[CTA Button]
"Usat per 200+ empreses"
"Més de 10.000 usuaris"
"Join companies like [logos]"
```

### 3. Risk Reversal

```
"Entrada gratuïta"
"Prova 14 dies gratis"
"Sense compromís"
"Cancel·la quan vulguis"
"Garantia de devolució"
```

### 4. FOMO

```
"No et quedis sense el contingut"
"Registra't aviat per assegurar la teva plaça"
"Les places s'estan esgotant"
```

---

## CTAs por Tipo de Landing

### SaaS/Product

| Objetivo | Primary CTA | Secondary CTA |
|----------|-------------|---------------|
| Trial signup | "Comença Prova Gratuïta" | "Veure Demo" |
| Demo request | "Sol·licita Demo" | "Veure Com Funciona" |
| Contact sales | "Parla amb un Expert" | "Descarrega Guia" |

### Event

| Objetivo | Primary CTA | Secondary CTA |
|----------|-------------|---------------|
| Registration | "Inscriu-te Ara" | "Vull l'Ebook" |
| Ticket sale | "Compra Entrada" | "Més Informació" |
| Waitlist | "Reserva Plaça" | "Notifica'm" |

### B2B Services

| Objetivo | Primary CTA | Secondary CTA |
|----------|-------------|---------------|
| Lead gen | "Sol·licita Consulta" | "Descarrega Cas d'Èxit" |
| Quote | "Demana Pressupost" | "Veure Serveis" |
| Contact | "Contacta'ns" | "Agenda Trucada" |

---

## Copy por Idioma

### Catalán

```
Primaris:
- "Comença Ara"
- "Sol·licita Demo"
- "Inscriu-te"
- "Descarrega Gratis"

Secundaris:
- "Veure Com Funciona"
- "Més Informació"
- "Parlar amb un Expert"
```

### Español

```
Primarios:
- "Empieza Ahora"
- "Solicita Demo"
- "Regístrate"
- "Descarga Gratis"

Secundarios:
- "Ver Cómo Funciona"
- "Más Información"
- "Hablar con un Experto"
```

### English

```
Primary:
- "Get Started"
- "Request Demo"
- "Sign Up"
- "Download Free"

Secondary:
- "See How It Works"
- "Learn More"
- "Talk to an Expert"
```

---

## Anti-Patterns

```
✗ "Submit" → Genérico, no comunica valor
✗ "Click Here" → Obvio, sin beneficio
✗ "Send" → Frío, transaccional
✗ "Buy" (solo) → Demasiado directo para B2B

✓ Siempre incluir beneficio o resultado
✓ Usar verbos específicos de la acción
✓ Personalizar al contexto
```

---

## Testing Recommendations

### A/B Test Priority

1. **Texto del CTA** - Mayor impacto
2. **Color del botón** - Contraste vs. marca
3. **Posición** - Above fold vs. después de contenido
4. **Tamaño** - Más grande suele funcionar mejor
5. **Urgencia** - Con vs. sin deadline

### Métricas

```
- CTR (Click-Through Rate)
- Conversion Rate
- Scroll depth hasta CTA
- Time to first click
```
