# Guías de Copy por Sección

## 1. Hero Section

**Objetivo**: Capturar atención, comunicar valor, impulsar primera acción.

### Elementos

| Elemento | Specs | Ejemplo |
|----------|-------|---------|
| Tag/Badge | 2-5 palabras, uppercase | "S.A.M. — Semantic Alignment Machine" |
| Headline | 6-12 palabras, transformación | "La tecnologia que converteix el GEO en ciència exacta" |
| Subheadline | 20-40 palabras, problema+solución | "Sense S.A.M., crear contingut GEO és anar a cegues..." |
| Primary CTA | Verbo + Valor | "Valida els teus Continguts" |
| Secondary CTA | Menor compromiso | "Veure Com Funciona" |

### Reglas

```
✓ Headline: Beneficio, no feature
✓ Subheadline: Dolor → Solución en una frase
✓ CTA: Verbo de acción + resultado
✗ No más de 3 CTAs
✗ No jerga técnica en headline
```

### Pattern SAM

```json
{
  "tag": "S.A.M. — Semantic Alignment Machine",
  "title": "La tecnologia que converteix el GEO en una ciència exacta i accionable",
  "subtitle": "Sense S.A.M., crear contingut GEO és literalment anar a cegues...",
  "buttons": [
    {"text": "Valida els teus Continguts", "variant": "primary"},
    {"text": "Veure Com Funciona S.A.M.", "variant": "secondary"}
  ]
}
```

### Pattern RADAR (Event)

```json
{
  "eventName": "RADAR",
  "year": "2026",
  "subtitle": "Les tendències i innovacions, aterrades a Catalunya",
  "hook": "Tu, segur que estàs preparat?",
  "info": [
    {"label": "Data", "value": "21 gener 2026"},
    {"label": "Hora", "value": "18:30h"},
    {"label": "Lloc", "value": "Museu del Disseny BCN"}
  ],
  "buttons": [
    {"text": "SÍ! VULL ASSISTIR", "variant": "primary"},
    {"text": "VULL L'EBOOK", "variant": "secondary"}
  ],
  "capacity": "Aforament presencial: 60 places"
}
```

---

## 2. Benefits Section

**Objetivo**: Traducir features en outcomes para el cliente.

### Estructura

```
Section Tag → Section Title → 3-4 Benefit Cards
```

### Benefit Card Format

```json
{
  "icon": "📊",
  "title": "Matching Score objectiu",
  "description": "Una puntuació precisa que mostra fins a quin punt una IA interpretaria aquell contingut com la resposta ideal."
}
```

### Reglas de Copy

```
✓ Empezar con "Tu" no con "Nosotros"
✓ Usar números específicos cuando sea posible
✓ Responder "So what?" en cada benefit
✓ Mezclar beneficios emocionales y racionales

✗ Evitar: "Nuestro potente algoritmo..."
✓ Mejor: "Saps exactament quants punts guanyes abans d'implementar"
```

### Opcional: Metrics Showcase

Después de benefits, mostrar ejemplo real:

```json
{
  "metricsTitle": "Exemple real d'anàlisi",
  "metrics": [
    {"label": "Citability", "value": "7.2"},
    {"label": "Structure", "value": "8.1"},
    {"label": "E-E-A-T", "value": "6.8"}
  ],
  "projection": {"from": "5.2", "to": "7.5"}
}
```

---

## 3. Differential Section

**Objetivo**: Establecer posicionamiento único vs alternativas.

### Estructura

```
Tag + Title + 4-5 Differential Items (vertical list)
```

### Differential Item Format

```json
{
  "title": "Cross-Model Alignment",
  "description": "Cada model (GPT, Claude, Llama, Mistral) interpreta el llenguatge diferent. S.A.M. compara com entenen el mateix contingut."
}
```

### Copy Patterns

```
"A diferència de [alternativa], nosaltres [diferencial]"
"Mentre altres [limitació], S.A.M. [capacitat]"
"L'únic sistema que [característica única]"
```

### Framework de Diferenciación

| Eje | Pregunta | Ejemplo |
|-----|----------|---------|
| Velocitat | ¿Más rápido? | "Resultats en minuts vs setmanes" |
| Precisió | ¿Más preciso? | "Matching Score objectiu, no opinions" |
| Cobertura | ¿Más completo? | "Cross-Model: GPT, Claude, Llama, Mistral" |
| Facilitat | ¿Más fácil? | "3 passos, sense codi" |
| Integració | ¿Mejor conectado? | "Integració amb GeoRadar i Prompt Atlas" |

---

## 4. How It Works Section

**Objetivo**: Reducir ansiedad de complejidad, mostrar camino al éxito.

### Estructura

```
Tag + Title + 3 Steps (numbered)
```

### Step Format

```json
{
  "number": "1",
  "title": "Defineix preguntes",
  "description": "S.A.M. analitza les preguntes estratègiques del teu pla GEO i les prepara per confrontar-les.",
  "list": ["Item opcional 1", "Item opcional 2"]
}
```

### Reglas

```
✓ Empezar cada título con VERBO (Defineix, Connecta, Optimitza)
✓ Máximo 2-3 frases por step
✓ Mostrar agencia del usuario, no solo features
✓ 3 steps es ideal (cognitivamente manejable)

✗ Evitar más de 5 steps
✗ Evitar jerga técnica excesiva
```

### Opcional: Integration Highlight

```json
{
  "integration": {
    "title": "Integració total amb el suite",
    "description": "GeoRadar → Prompt Atlas → S.A.M.",
    "flow": "Identificació → Generació → Validació"
  }
}
```

---

## 5. Features/Capabilities Section

**Objetivo**: Proveer detalle para compradores analíticos.

### Estructura

```
Tag + Title + Feature Grid (8-9 items, 3x3)
```

### Feature Item Format

```json
{
  "title": "Matching Score",
  "description": "Puntuació precisa de compatibilitat entre preguntes i continguts."
}
```

### Reglas

```
✓ Títulos cortos (2-4 palabras)
✓ Descripciones 15-25 palabras
✓ Agrupar por categoría si hay muchas
✓ Linking features → benefits

✗ No repetir lo de Benefits section
✗ No ser demasiado técnico
```

---

## 6. Testimonials Section

**Objetivo**: Validación social a través de pares.

### Estructura

```
Tag + Title + 2-4 Testimonial Cards
```

### Testimonial Format

```json
{
  "quote": "Amb S.A.M. vam descobrir que la meitat dels nostres continguts eren invisibles per als models.",
  "author": "Head of Content Strategy",
  "company": "Optional: Company Name"
}
```

### Reglas de Selección

```
✓ Incluir resultados específicos cuando sea posible
✓ Variar roles/industrias de los testimonios
✓ Usar lenguaje conversacional (no corporate)
✓ Máximo 2-3 frases por quote

✗ Evitar quotes genéricos: "Gran producto, lo recomiendo"
✗ Evitar demasiados testimonios (3-4 max)
```

---

## 7. Before/After Section

**Objetivo**: Visualizar la transformación.

### Estructura

```
Tag + Title + Two Columns (Before/After) + Footer Statement
```

### Format

```json
{
  "before": {
    "title": "Abans de S.A.M.",
    "items": [
      "Crear continguts sense saber si funcionen",
      "Incertesa total sobre el match",
      "Impossibilitat de predir impacte"
    ]
  },
  "after": {
    "title": "Després de S.A.M.",
    "items": [
      "Validació científica del match",
      "Matching Score objectiu",
      "Predicció exacta del guany"
    ]
  },
  "footer": [
    "De la incertesa a la ciència.",
    "De l'aposta al control."
  ]
}
```

### Reglas

```
✓ Mismo número de items en ambos lados
✓ Before: emocional, dolor
✓ After: racional, solución
✓ Footer: frase aspiracional de cierre
```

---

## 8. Use Cases Section

**Objetivo**: Ayudar a visitantes a auto-identificarse.

### Estructura

```
Tag + Title + 5-6 Use Case Cards
```

### Use Case Format

```json
{
  "title": "Content & GEO Teams",
  "description": "Validació científica de continguts abans de publicar-los."
}
```

### Reglas

```
✓ Usar títulos de rol que visitantes reconozcan
✓ Explicar valor específico para cada perfil
✓ Cubrir audiencias primarias Y secundarias
```

---

## 9. FAQ Section

**Objetivo**: Resolver objeciones, proveer información.

### Estructura

```
Tag + Title + 6-8 FAQ Items (expandable)
```

### FAQ Format

```json
{
  "question": "Què és S.A.M.?",
  "answer": "S.A.M. (Semantic Alignment Machine) és la plataforma que valida si els continguts GEO realment compleixen el seu objectiu."
}
```

### Preguntas a Incluir

| Tipo | Ejemplo |
|------|---------|
| Definición | "Què és [producto]?" |
| Integración | "Com s'integra amb [X]?" |
| Pricing/Value | "Quin és el preu?" |
| Technical | "Quins models analitza?" |
| Process | "Com funciona [feature]?" |
| Objection | "Funciona per a [caso edge]?" |

### Reglas

```
✓ Usar preguntas reales de clientes
✓ Respuestas 3-5 frases max
✓ Terminar respuestas con confianza
✓ Abordar objeciones de precio/valor
```

---

## 10. Final CTA Section

**Objetivo**: Capturar visitantes listos para convertir.

### Estructura

```
Title + Subtitle + CTA Buttons (same as Hero)
```

### Format

```json
{
  "title": "Converteix el GEO en una ciència exacta",
  "subtitle": "Sense S.A.M., el GEO és una aposta. Amb S.A.M., és una ciència.",
  "buttons": [
    {"text": "Valida els teus Continguts", "variant": "primary"},
    {"text": "Parlar amb un Consultor", "variant": "secondary"}
  ]
}
```

### Reglas

```
✓ Repetir propuesta de valor del Hero
✓ Crear urgencia si es apropiado
✓ Añadir trust signals si es necesario
✓ Mismo CTA primario que en Hero

Opcional: añadir nota de urgencia
"Només 60 places presencials · Entrada gratuïta"
```
