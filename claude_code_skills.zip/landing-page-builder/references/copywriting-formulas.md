# Fórmulas de Copywriting para Landing Pages

## PAS (Problem-Agitate-Solution)

**Usar cuando**: La audiencia ya conoce su dolor/problema.

| Fase | Objetivo | Ejemplo |
|------|----------|---------|
| **Problem** | Nombrar el problema claramente | "Crear contingut GEO sense saber si funciona" |
| **Agitate** | Amplificar consecuencias | "Literalment anar a cegues, perdent temps i recursos" |
| **Solution** | Presentar tu oferta | "S.A.M. és l'única manera fiable de verificar" |

### Aplicación en Secciones

- **Hero**: Problem en subtitle, Solution en headline
- **Before/After**: Problem en "Before", Solution en "After"
- **FAQ**: Agitate en pregunta, Solution en respuesta

---

## AIDA (Attention-Interest-Desire-Action)

**Usar cuando**: Audiencia fría, necesitan captar atención primero.

| Fase | Objetivo | Sección LP |
|------|----------|------------|
| **Attention** | Hook impactante | Hero headline |
| **Interest** | Presentar beneficios relevantes | Benefits section |
| **Desire** | Crear conexión emocional | Testimonials, Before/After |
| **Action** | CTA claro | Final CTA |

### Ejemplos de Headlines (Attention)

```
✓ "Les tendències que canviaran com treballes"
✓ "La tecnologia que converteix el GEO en ciència"
✗ "Benvingut al nostre producte" (aburrido)
```

---

## PASTOR (Problem-Amplify-Story-Transformation-Offer-Response)

**Usar cuando**: Landing pages largas, productos high-ticket, alta consideración.

| Fase | Contenido | Sección LP |
|------|-----------|------------|
| **Problem** | Identificar dolor | Hero subtitle |
| **Amplify** | Consecuencias de no resolver | Differential |
| **Story** | Narrativa relatable | Testimonials |
| **Transformation** | Visión antes/después | Before/After |
| **Offer** | Detalles de la solución | Features, How It Works |
| **Response** | Call to action | Final CTA |

### Amplify Patterns

```
"Si no actues ara..."
"Cada dia que passes sense..."
"Mentre tu esperes, els teus competidors..."
```

---

## FAB (Features-Advantages-Benefits)

**Usar cuando**: Productos técnicos con muchas features, audiencia que conoce alternativas.

| Nivel | Pregunta | Ejemplo |
|-------|----------|---------|
| **Feature** | Què té? | "Matching Score objectiu" |
| **Advantage** | Per què importa tècnicament? | "Puntuació precisa de compatibilitat" |
| **Benefit** | Com millora la vida del usuari? | "Saps exactament què funciona abans de publicar" |

### Feature Grid Pattern

```json
{
  "title": "Matching Score",
  "description": "Puntuació precisa que mostra compatibilitat entre continguts i preguntes. Saps exactament què funciona."
}
```

---

## Selección de Fórmula

| Awareness del Client | Fórmula Recomendada |
|---------------------|---------------------|
| No saben que tienen problema | AIDA |
| Conocen el problema | PAS |
| Conocen soluciones, comparan | FAB |
| Alta consideración, decisión compleja | PASTOR |

---

## Power Words por Idioma

### Catalán
```
Descobreix, Transforma, Garanteix, Exclusiu, Immediat
Sense risc, Provat, Científic, Mesurable, Accionable
```

### Español
```
Descubre, Transforma, Garantiza, Exclusivo, Inmediato
Sin riesgo, Probado, Científico, Medible, Accionable
```

### English
```
Discover, Transform, Guarantee, Exclusive, Instant
Risk-free, Proven, Scientific, Measurable, Actionable
```

---

## Anti-Patterns (Evitar)

```
✗ "Somos los mejores" → ¿Según quién?
✗ "Solución innovadora" → Vacío, todos lo dicen
✗ "Fácil y simple" → Puede parecer trivial
✗ "Revolucionario" → Sobreusado
✗ "Disruptivo" → Cliché tech
```

### Mejor así:

```
✓ "Reduce un 70% el temps de validació" → Específico
✓ "Usat per 200+ empreses" → Social proof
✓ "Resultats en 24h vs 8 setmanes" → Comparativo
```
