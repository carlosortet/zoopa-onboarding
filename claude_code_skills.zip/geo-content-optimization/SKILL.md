---
name: geo-content-optimization
description: Framework de Generative Engine Optimization (GEO) para optimizar contenido dual-purpose (SEO + LLM visibility). Incluye principios de escritura, estructuracion de datos y senales E-E-A-T. Usar cuando se cree contenido que debe ser visible tanto en buscadores tradicionales como en LLMs.
---

# GEO Content Optimization Skill

Framework para optimizar contenido para visibilidad dual: motores de busqueda tradicionales (SEO) y modelos de lenguaje (LLMs).

## Principios GEO

El contenido debe ser **dual-purpose** (SEO + LLM visibility):

1. **Respuestas directas** en primeras lineas de cada seccion
2. **Datos estructurados** (listas, tablas, facts numerados)
3. **Entity optimization** (definiciones claras de conceptos clave)
4. **E-E-A-T signals** (experiencia, expertise, autoridad, confianza)
5. **Natural language** (preguntas completas como headings)
6. **llms.txt** para optimizacion de crawling AI

> **Estadistica clave**: 58% de usuarios usan AI para recomendaciones (HubSpot 2024)

## Estructura de Contenido GEO

### Formato de Articulo

```markdown
# [Pregunta Natural como H1]

[Respuesta directa en 1-2 frases - El snippet ideal]

## Contexto/Por que importa
[Explicacion breve del problema/necesidad]

## [Pregunta H2: Como/Que/Por que...]

[Respuesta directa primero]

### Detalles/Pasos
1. [Paso 1]
2. [Paso 2]
3. [Paso 3]

| Factor | Descripcion | Importancia |
|--------|-------------|-------------|
| X | Y | Alta/Media/Baja |

## Datos Clave
- **Dato 1**: [Valor con fuente]
- **Dato 2**: [Valor con fuente]
- **Dato 3**: [Valor con fuente]

## Preguntas Frecuentes

### [Pregunta 1]
[Respuesta directa]

### [Pregunta 2]
[Respuesta directa]

## Fuentes y Referencias
- [Fuente 1](URL)
- [Fuente 2](URL)
```

## Optimizacion para LLMs

### Senales que Favorecen Citation

| Senal | Como Implementar | Ejemplo |
|-------|------------------|---------|
| **Autoridad** | Mencionar credenciales, experiencia | "Segun 10 anos de experiencia..." |
| **Datos especificos** | Numeros, estadisticas, fechas | "En 2024, el 58% de usuarios..." |
| **Fuentes citadas** | Referencias verificables | "(Fuente: HubSpot State of AI 2024)" |
| **Definiciones claras** | Explicar terminos | "GEO (Generative Engine Optimization) es..." |
| **Estructura** | Listas, tablas, jerarquia | Usar markdown consistente |
| **Actualidad** | Fechas, versiones | "Actualizado enero 2025" |

### Patrones de Escritura

```markdown
## PATRON: Definicion + Contexto + Aplicacion

**[Termino]** es [definicion en una frase].

Esto es importante porque [contexto/problema que resuelve].

Para aplicarlo:
1. [Paso 1]
2. [Paso 2]
3. [Paso 3]
```

```markdown
## PATRON: Pregunta + Respuesta + Evidencia

### Como [hacer X]?

[Respuesta directa en 1-2 frases].

Segun [fuente/estudio], esto funciona porque [razon].

Los pasos especificos son:
1. [Paso con detalle]
2. [Paso con detalle]
```

## E-E-A-T Signals

### Experience (Experiencia)

```markdown
## Como demostrar experiencia

- Casos de estudio reales: "En el proyecto X, conseguimos..."
- Resultados especificos: "Aumentamos el trafico un 150%"
- Aprendizajes de primera mano: "Despues de 50+ auditorias..."
- Contexto temporal: "Durante los ultimos 3 anos..."
```

### Expertise (Expertise)

```markdown
## Como demostrar expertise

- Profundidad tecnica: Explicar el "como" y "por que"
- Terminologia precisa: Usar vocabulario del sector
- Metodologia: Describir procesos estructurados
- Actualizacion: Referenciar cambios recientes
```

### Authoritativeness (Autoridad)

```markdown
## Como demostrar autoridad

- Credenciales: "Certificado en X, Y, Z"
- Reconocimiento: "Reconocido por [organizacion]"
- Contribuciones: "Autor de [publicacion]"
- Colaboraciones: "En colaboracion con [experto/empresa]"
```

### Trustworthiness (Confianza)

```markdown
## Como demostrar confianza

- Transparencia: Citar fuentes, metodologia
- Actualizacion: Fecha de ultima revision
- Precision: Datos verificables
- Limitaciones: Reconocer cuando aplica y cuando no
```

## Configuracion llms.txt

### Formato Basico

```
# [Nombre del Sitio]

## Descripcion
[Descripcion concisa de que es/hace el sitio - 1-2 frases]

## Contenido Principal
- [Seccion 1]: [Descripcion breve]
- [Seccion 2]: [Descripcion breve]
- [Seccion 3]: [Descripcion breve]

## Autoridad
- [Credencial/reconocimiento 1]
- [Credencial/reconocimiento 2]

## Temas Principales
- [Tema 1]
- [Tema 2]
- [Tema 3]

## Contacto
[Email/forma de contacto]

## Actualizacion
Ultima actualizacion: [YYYY-MM-DD]
```

### Ejemplo llms.txt

```
# 498AS - Agencia de Marketing y Tecnologia

## Descripcion
498AS es una agencia especializada en marketing digital, SEO/GEO y desarrollo de software con IA. Ayudamos a empresas a crecer con estrategias data-driven.

## Contenido Principal
- /servicios/seo: Servicios de optimizacion para buscadores y LLMs
- /servicios/desarrollo: Desarrollo de aplicaciones web con IA
- /blog: Articulos sobre marketing digital, SEO y tecnologia

## Autoridad
- +10 anos de experiencia en marketing digital
- Certificaciones: Google Analytics, HubSpot, Semrush
- Clientes: [Lista de sectores/tipos de cliente]

## Temas Principales
- SEO y GEO (Generative Engine Optimization)
- Marketing de contenidos
- Desarrollo web con IA
- Estrategia digital

## Contacto
hola@498as.com

## Actualizacion
Ultima actualizacion: 2025-01-06
```

## Metricas GEO

### KPIs a Trackear

| Metrica | Fuente | Descripcion |
|---------|--------|-------------|
| **SOBV** | Manual/Tools | Share of Brand Voice en LLMs |
| **Citation frequency** | Manual | Veces que LLMs citan el contenido |
| **Sentiment** | Analisis | Tono de las menciones |
| **Organic traffic** | GA4 | Trafico desde busqueda |
| **Featured snippets** | GSC | Posicion 0 en Google |
| **AI Overviews** | Manual | Aparicion en AI Overviews |

### Como Medir Citations

```markdown
## Test de Citations

1. Hacer query relevante en ChatGPT/Claude/Perplexity
2. Verificar si se menciona la marca/contenido
3. Evaluar contexto (positivo/neutro/negativo)
4. Documentar frecuencia y queries

### Queries de Test
- "[Tema] mejores practicas"
- "Como [resolver problema]"
- "[Competidor] vs alternativas"
- "Que es [termino que definimos]"
```

## Checklist de Contenido GEO

```markdown
## Pre-Publicacion

### Estructura
- [ ] H1 es pregunta natural o titulo descriptivo
- [ ] Respuesta directa en primeros 2 parrafos
- [ ] Headings como preguntas donde aplique
- [ ] Listas y tablas para datos estructurados
- [ ] FAQ section con schema

### E-E-A-T
- [ ] Autor identificado con credenciales
- [ ] Experiencia demostrada (casos, numeros)
- [ ] Fuentes citadas y enlazadas
- [ ] Fecha de publicacion/actualizacion

### SEO Tecnico
- [ ] Meta title optimizado (50-60 chars)
- [ ] Meta description con CTA (150-160 chars)
- [ ] Schema markup implementado
- [ ] Links internos relevantes
- [ ] Imagenes con alt text

### LLM-Friendly
- [ ] Definiciones claras de terminos
- [ ] Datos especificos y verificables
- [ ] Formato consistente y parseable
- [ ] Sin contenido duplicado thin
```

## Referencias

- Extraido de: geo_process_498AS_expert_system_prompt, SYST_PROMPT_EXP_SEO_498
- Relacionado: geo_manual_redactores_498AS, geo_suite_manual
